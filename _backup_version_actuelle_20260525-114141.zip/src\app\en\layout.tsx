import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Vemo Technology | US LLC Formation",
  description:
    "US LLC formation platform for non-residents with secure payment, client portal, Documents and admin tracking.",
};

export default function EnglishLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div lang="en">
      {children}
    </div>
  );
}


