"use client";

import { FormEvent, useMemo, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import { SiteHeader } from "@/components/SiteChrome";

type Lang = "fr" | "en";

const copy = {
  fr: {
    eyebrow: "Connexion admin",
    title: "Accéder à Vemo Admin.",
    text: "Espace réservé aux administrateurs autorisés.",
    email: "Email admin",
    password: "Mot de passe",
    submit: "Se connecter à l’admin",
    loading: "Connexion...",
    clientLogin: "Connexion client",
    error: "Connexion admin impossible.",
    denied: "Cet email n’est pas autorisé comme administrateur.",
    env: "Variables Supabase publiques manquantes.",
  },
  en: {
    eyebrow: "Admin login",
    title: "Access Vemo Admin.",
    text: "Reserved for authorized administrators.",
    email: "Admin email",
    password: "Password",
    submit: "Log in to admin",
    loading: "Signing in...",
    clientLogin: "Client login",
    error: "Admin login failed.",
    denied: "This email is not authorized as an administrator.",
    env: "Missing public Supabase variables.",
  },
};

function getSupabaseBrowser() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anon) return null;

  return createClient(url, anon);
}

export default function AdminLoginPage({ lang }: { lang: Lang }) {
  const t = copy[lang];

  const supabase = useMemo(() => getSupabaseBrowser(), []);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");
    setLoading(true);

    try {
      if (!supabase) {
        throw new Error(t.env);
      }

      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });

      if (signInError || !data.session?.access_token) {
        throw new Error(signInError?.message || t.error);
      }

      const response = await fetch("/api/admin/me", {
        headers: {
          Authorization: `Bearer ${data.session.access_token}`,
        },
      });

      const result = await response.json();

      if (!response.ok) {
        await supabase.auth.signOut();
        throw new Error(result.error || t.denied);
      }

      window.location.href = `/${lang}/admin`;
    } catch (err) {
      setError(err instanceof Error ? err.message : t.error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#f4f7fa] text-slate-950">
      <SiteHeader lang={lang} />

      <section className="mx-auto flex min-h-[620px] max-w-5xl items-center justify-center px-6 py-16">
        <div className="w-full max-w-xl rounded-[2rem] border border-slate-100 bg-white p-8 shadow-xl shadow-slate-200/70 md:p-10">
          <div className="mb-8">
            <p className="text-sm font-black uppercase tracking-[0.22em] text-[#0e7490]">
              {t.eyebrow}
            </p>

            <h1 className="mt-4 text-4xl font-black tracking-[-0.06em] md:text-5xl">
              {t.title}
            </h1>

            <p className="mt-4 text-sm font-bold leading-7 text-slate-500">
              {t.text}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <label className="block">
              <span className="mb-2 block text-sm font-black text-slate-700">
                {t.email}
              </span>
              <input
                type="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                required
                placeholder="admin@email.com"
                className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
              />
            </label>

            <label className="block">
              <span className="mb-2 block text-sm font-black text-slate-700">
                {t.password}
              </span>
              <input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                required
                placeholder="••••••••"
                className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
              />
            </label>

            {error && (
              <div className="rounded-2xl border border-red-100 bg-red-50 px-5 py-4 text-sm font-black text-red-700">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-[#0f2a4f] px-6 py-4 text-sm font-black text-white shadow-lg shadow-slate-900/20 transition hover:bg-[#0b1f3d] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? t.loading : t.submit}
            </button>
          </form>

          <div className="mt-7 border-t border-slate-100 pt-5 text-center">
            <a
              href={`/${lang}/connexion`}
              className="text-sm font-black text-[#0e7490]"
            >
              {t.clientLogin}
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}