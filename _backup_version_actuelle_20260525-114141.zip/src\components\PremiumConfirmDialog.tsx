"use client";

type PremiumConfirmDialogProps = {
  open: boolean;
  eyebrow?: string;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  tone?: "danger" | "info" | "success";
  loading?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
};

export default function PremiumConfirmDialog({
  open,
  eyebrow = "Confirmation",
  title,
  message,
  confirmLabel = "Confirmer",
  cancelLabel = "Annuler",
  tone = "danger",
  loading = false,
  onConfirm,
  onCancel,
}: PremiumConfirmDialogProps) {
  if (!open) return null;

  const icon =
    tone === "danger" ? "!" : tone === "success" ? "✓" : "i";

  const iconClass =
    tone === "danger"
      ? "bg-red-50 text-red-600"
      : tone === "success"
        ? "bg-emerald-50 text-emerald-700"
        : "bg-cyan-50 text-[#0e7490]";

  const confirmClass =
    tone === "danger"
      ? "bg-red-600 hover:bg-red-700 shadow-red-900/20"
      : "bg-[#0e7490] hover:bg-[#0b647c] shadow-cyan-900/20";

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-5">
      <button
        type="button"
        aria-label="Fermer"
        onClick={loading ? undefined : onCancel}
        className="absolute inset-0 bg-slate-950/45 backdrop-blur-sm"
      />

      <section className="relative w-full max-w-[430px] overflow-hidden rounded-[1.6rem] border border-white/70 bg-white shadow-2xl shadow-slate-950/25">
        <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-[#0e7490] via-cyan-300 to-[#0f2a4f]" />

        <div className="p-6">
          <div className="flex items-start gap-4">
            <div
              className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-xl font-black ${iconClass}`}
            >
              {icon}
            </div>

            <div className="min-w-0">
              <p className="text-xs font-black uppercase tracking-[0.22em] text-[#0e7490]">
                {eyebrow}
              </p>

              <h2 className="mt-2 text-2xl font-black tracking-[-0.05em] text-slate-950">
                {title}
              </h2>

              <p className="mt-3 text-sm font-bold leading-6 text-slate-500">
                {message}
              </p>
            </div>
          </div>

          <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={onCancel}
              disabled={loading}
              className="rounded-2xl border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-950 transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {cancelLabel}
            </button>

            <button
              type="button"
              onClick={onConfirm}
              disabled={loading}
              className={`rounded-2xl px-5 py-3 text-sm font-black text-white shadow-lg transition disabled:cursor-not-allowed disabled:opacity-60 ${confirmClass}`}
            >
              {loading ? "Traitement..." : confirmLabel}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}