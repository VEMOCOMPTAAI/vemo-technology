type HeaderProps = {
  lang: "fr" | "en";
  active?: "home" | "pricing" | "faq" | "contact" | "start";
};

export function SiteHeader({ lang, active = "home" }: HeaderProps) {
  const isFr = lang === "fr";

  const mainLinks = isFr
    ? [
        { label: "Accueil", href: "/fr", key: "home" },
        { label: "Tarifs", href: "/fr/tarifs", key: "pricing" },
        { label: "FAQ", href: "/fr/faq", key: "faq" },
        { label: "Contact", href: "/fr/contact", key: "contact" },
      ]
    : [
        { label: "Home", href: "/en", key: "home" },
        { label: "Pricing", href: "/en/pricing", key: "pricing" },
        { label: "FAQ", href: "/en/faq", key: "faq" },
        { label: "Contact", href: "/en/contact", key: "contact" },
      ];

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/95 backdrop-blur-xl">
      <div className="vemo-container flex items-center justify-between gap-5 py-4">
        <a href={isFr ? "/fr" : "/en"} className="flex shrink-0 items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-[#0e7490] to-[#0f2a4f] text-lg font-black text-white shadow-lg shadow-cyan-200/60">
            V
          </div>

          <div>
            <p className="text-2xl font-black tracking-[-0.04em] text-[#0f172a]">
              Vemo Technology
            </p>
            <p className="hidden text-xs font-bold text-slate-500 sm:block">
              {isFr ? "US LLC pour non-résidents" : "US LLC for non-residents"}
            </p>
          </div>
        </a>

        <nav className="hidden items-center gap-2 lg:flex">
          {mainLinks.map((link) => {
            const isActive = active === link.key;

            return (
              <a
                key={link.key}
                href={link.href}
                className={[
                  "rounded-full px-4 py-2 text-sm font-black transition",
                  isActive
                    ? "bg-cyan-50 text-[#0e7490]"
                    : "text-slate-600 hover:bg-slate-50 hover:text-[#0f172a]",
                ].join(" ")}
              >
                {link.label}
              </a>
            );
          })}
        </nav>

        <div className="flex shrink-0 items-center gap-2">
          <div className="hidden items-center gap-1 rounded-full border border-slate-200 bg-white p-1 shadow-sm md:flex">
            <a
              href="/fr"
              className={[
                "rounded-full px-3 py-2 text-xs font-black transition",
                isFr ? "bg-[#0e7490] text-white" : "text-slate-500 hover:bg-slate-50",
              ].join(" ")}
            >
              FR
            </a>

            <a
              href="/en"
              className={[
                "rounded-full px-3 py-2 text-xs font-black transition",
                !isFr ? "bg-[#0e7490] text-white" : "text-slate-500 hover:bg-slate-50",
              ].join(" ")}
            >
              EN
            </a>
          </div>

          <a
            href={isFr ? "/fr/commencer" : "/en/start"}
            className="vemo-btn-primary"
          >
            {isFr ? "Démarrer" : "Start"}
            <span>→</span>
          </a>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter({ lang }: { lang: "fr" | "en" }) {
  const isFr = lang === "fr";

  const commercialLinks = isFr
    ? [
        { label: "Accueil", href: "/fr" },
        { label: "Tarifs", href: "/fr/tarifs" },
        { label: "FAQ", href: "/fr/faq" },
        { label: "Contact", href: "/fr/contact" },
        { label: "Commencer", href: "/fr/commencer" },
      ]
    : [
        { label: "Home", href: "/en" },
        { label: "Pricing", href: "/en/pricing" },
        { label: "FAQ", href: "/en/faq" },
        { label: "Contact", href: "/en/contact" },
        { label: "Start", href: "/en/start" },
      ];

  const legalLinks = isFr
    ? [
        { label: "Conditions d’utilisation", href: "/fr/conditions" },
        { label: "Confidentialité", href: "/fr/confidentialite" },
        { label: "Remboursement", href: "/fr/remboursement" },
      ]
    : [
        { label: "Terms of Use", href: "/en/terms" },
        { label: "Privacy Policy", href: "/en/privacy" },
        { label: "Refund Policy", href: "/en/refund-policy" },
      ];

  return (
    <footer className="mt-12 bg-[#0f2a4f] px-6 py-12 text-white">
      <div className="vemo-container grid gap-10 md:grid-cols-[1.2fr_0.8fr_0.8fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-lg font-black text-[#0e7490]">
              V
            </div>

            <div>
              <p className="text-2xl font-black tracking-[-0.04em]">Vemo Technology</p>
              <p className="text-xs font-bold text-cyan-100">
                {isFr ? "US LLC pour non-résidents" : "US LLC for non-residents"}
              </p>
            </div>
          </div>

          <p className="mt-5 max-w-sm text-sm font-medium leading-7 text-slate-300">
            {isFr
              ? "Plateforme premium pour accompagner les entrepreneurs non-résidents dans la création de leur LLC américaine."
              : "A premium platform helping non-resident entrepreneurs set up their US LLC."}
          </p>
        </div>

        <div>
          <p className="font-black text-white">Navigation</p>
          <div className="mt-4 space-y-3 text-sm font-bold text-slate-300">
            {commercialLinks.map((link) => (
              <p key={link.href}>
                <a href={link.href} className="hover:text-cyan-100">
                  {link.label}
                </a>
              </p>
            ))}
          </div>
        </div>

        <div>
          <p className="font-black text-white">{isFr ? "Légal" : "Legal"}</p>
          <div className="mt-4 space-y-3 text-sm font-bold text-slate-300">
            {legalLinks.map((link) => (
              <p key={link.href}>
                <a href={link.href} className="hover:text-cyan-100">
                  {link.label}
                </a>
              </p>
            ))}
          </div>
        </div>

        <div>
          <p className="font-black text-white">
            {isFr ? "Note importante" : "Important note"}
          </p>

          <p className="mt-4 text-sm font-medium leading-7 text-slate-300">
            {isFr
              ? "Vemo Technology fournit un accompagnement administratif et documentaire. Ce service ne remplace pas un avocat, un CPA ou un conseiller fiscal."
              : "Vemo Technology provides administrative and document support. This service does not replace an attorney, CPA or tax advisor."}
          </p>

          <div className="mt-6 rounded-2xl bg-white/10 p-4 text-sm font-black text-cyan-100">
            © {new Date().getFullYear()} Vemo Technology
          </div>
        </div>
      </div>
    </footer>
  );
}




