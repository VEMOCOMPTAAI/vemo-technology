import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

const packages = [
  {
    name: "Starter",
    price: "$199",
    description: "Pour démarrer simplement votre dossier LLC.",
    features: ["Questionnaire LLC", "Préparation dossier", "Suivi admin"],
  },
  {
    name: "Standard",
    price: "$349",
    description: "La formule recommandée pour la plupart des non-résidents.",
    features: ["Everything in Starter", "Accompagnement EIN application", "Operating Agreement", "Enhanced case follow-up"],
    highlighted: true,
  },
  {
    name: "Premium",
    price: "$599",
    description: "Pour un accompagnement plus complet et structuré.",
    features: ["Tout Standard", "Préparation Stripe / PayPal", "Checklist bancaire", "Priority supportt"],
  },
];

export default function FrenchPricingPage() {
  return (
    <main className="min-h-screen text-slate-950">
      <SiteHeader lang="fr" active="pricing" />

      <section className="py-14 md:py-20">
        <div className="vemo-container">
          <div className="mx-auto max-w-3xl text-center">
            <p className="vemo-badge mx-auto">Tarifs</p>

            <h1 className="mt-6 text-4xl font-black leading-[1] tracking-[-0.05em] text-[#0f172a] md:text-6xl">
              Choisissez l’accompagnement adapté à votre projet LLC.
            </h1>

            <p className="mt-6 text-base font-semibold leading-8 text-slate-600">
              Des formules claires pour lancer votre dossier avec une structure simple,
              professionnelle et adaptée aux non-résidents.
            </p>
          </div>

          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {packages.map((item) => (
              <div
                key={item.name}
                className={[
                  "rounded-[1.75rem] border bg-white p-7 shadow-xl shadow-slate-200/60",
                  item.highlighted
                    ? "border-[#0e7490] ring-1 ring-[#0e7490]/20"
                    : "border-slate-200",
                ].join(" ")}
              >
                {item.highlighted && (
                  <p className="-mt-10 mb-5 w-fit rounded-full bg-[#0e7490] px-4 py-1 text-xs font-black uppercase text-white">
                    Recommandé
                  </p>
                )}

                <p className="text-sm font-black uppercase tracking-wide text-[#0e7490]">
                  {item.name}
                </p>

                <p className="mt-4 text-5xl font-black tracking-[-0.05em] text-[#0f172a]">
                  {item.price}
                </p>

                <p className="mt-4 text-sm font-semibold leading-7 text-slate-600">
                  {item.description}
                </p>

                <div className="mt-7 space-y-3">
                  {item.features.map((feature) => (
                    <p key={feature} className="text-sm font-bold text-slate-600">
                      ✓ {feature}
                    </p>
                  ))}
                </div>

                <a
                  href="/fr/commencer"
                  className={[
                    "mt-8 flex rounded-xl px-5 py-4 text-center text-sm font-black transition",
                    item.highlighted
                      ? "justify-center bg-[#0e7490] text-white hover:bg-[#0f2a4f]"
                      : "justify-center border border-slate-200 text-[#0f172a] hover:bg-cyan-50",
                  ].join(" ")}
                >
                  Commencer
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter lang="fr" />
    </main>
  );
}

