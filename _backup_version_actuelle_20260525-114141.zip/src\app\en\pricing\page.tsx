import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

const packages = [
  {
    name: "New Mexico Starter",
    price: "$119",
    description: "A simple and cost-effective way to launch your New Mexico LLC.",
    features: [
      "New Mexico LLC formation",
      "Registered Agent included for the first year",
      "Registered Agent renewal: $35/year",
      "EIN application included — 10 to 30 business days",
      "US phone number included for 3 months",
      "Basic administrative follow-up",
    ],
  },
  {
    name: "New Mexico Standard",
    price: "$179",
    description: "A practical package to launch your LLC and prepare your payment tools.",
    features: [
      "Everything in Starter",
      "Stripe / PayPal / Wise / Mercury preparation",
      "Business account setup guidance",
      "Enhanced case follow-up",
      "Standard priority support",
    ],
    highlighted: true,
  },
  {
    name: "New Mexico Advanced",
    price: "$199",
    description: "A complete package to create your LLC, prepare your business tools and build your online presence.",
    features: [
      "Everything in Standard",
      "Stripe / PayPal / Wise / Mercury / Payoneer preparation",
      "Professional website preparation",
      "Premium assistance",
      "Priority support",
      "End-to-end case follow-up",
    ],
  },
  {
    name: "Wyoming Starter",
    price: "$189",
    description: "A fast and essential setup for launching your Wyoming LLC.",
    features: [
      "Wyoming LLC formation",
      "Registered Agent included for the first year",
      "Registered Agent renewal: $25/year",
      "EIN application included — 3 to 7 business days",
      "US phone number included for 3 months",
      "Basic administrative follow-up",
    ],
  },
  {
    name: "Wyoming Standard",
    price: "$239",
    description: "Recommended for non-resident founders who want a more business-ready LLC setup.",
    features: [
      "Everything in Starter",
      "Stripe / PayPal / Wise / Mercury preparation",
      "Business account setup guidance",
      "Enhanced case follow-up",
      "Standard priority support",
    ],
    highlighted: true,
  },
  {
    name: "Wyoming Advanced",
    price: "$299",
    description: "A premium package for founders who want a complete business-ready setup.",
    features: [
      "Everything in Standard",
      "Stripe / PayPal / Wise / Mercury / Payoneer preparation",
      "Professional website preparation",
      "Premium assistance",
      "Priority support",
      "End-to-end case follow-up",
    ],
  },
];

export default function EnglishPricingPage() {
  return (
    <main className="min-h-screen text-slate-950">
      <SiteHeader lang="en" active="pricing" />

      <section className="py-14 md:py-20">
        <div className="vemo-container">
          <div className="mx-auto max-w-3xl text-center">
            <p className="vemo-badge mx-auto">Pricing</p>

            <h1 className="mt-6 text-4xl font-black leading-[1] tracking-[-0.05em] text-[#0f172a] md:text-6xl">
              Choose the right support level for your LLC project.
            </h1>

            <p className="mt-6 text-base font-semibold leading-8 text-slate-600">
              Clear packages to launch your case with a simple, professional
              structure adapted to non-resident founders.
            </p>
          </div>

          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            {packages.map((item) => (
              <div
                key={item.name}
                className={[
                  "rounded-[1.75rem] border bg-white p-7 shadow-xl shadow-slate-200/60",
                  item.highlighted
                    ? "border-[#0e7490] ring-1 ring-[#0e7490]/20"
                    : "border-slate-200",
                ].join(" ")}
              >
                {item.highlighted && (
                  <p className="-mt-10 mb-5 w-fit rounded-full bg-[#0e7490] px-4 py-1 text-xs font-black uppercase text-white">
                    Recommended
                  </p>
                )}

                <p className="text-sm font-black uppercase tracking-wide text-[#0e7490]">
                  {item.name}
                </p>

                <p className="mt-4 text-5xl font-black tracking-[-0.05em] text-[#0f172a]">
                  {item.price}
                </p>

                <p className="mt-4 text-sm font-semibold leading-7 text-slate-600">
                  {item.description}
                </p>

                <div className="mt-7 space-y-3">
                  {item.features.map((feature) => (
                    <p key={feature} className="text-sm font-bold text-slate-600">
                      ✓ {feature}
                    </p>
                  ))}
                </div>

                <a
                  href="/en/start"
                  className={[
                    "mt-8 flex rounded-xl px-5 py-4 text-center text-sm font-black transition",
                    item.highlighted
                      ? "justify-center bg-[#0e7490] text-white hover:bg-[#0f2a4f]"
                      : "justify-center border border-slate-200 text-[#0f172a] hover:bg-cyan-50",
                  ].join(" ")}
                >
                  Start
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <SiteFooter lang="en" />
    </main>
  );
}


