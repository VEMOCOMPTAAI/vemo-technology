"use client";


import BankTransferProofPanel from "@/components/BankTransferProofPanel";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import countriesRaw from "world-countries";
import {
  getCountryCallingCode,
  isValidPhoneNumber,
  parsePhoneNumberFromString,
} from "libphonenumber-js";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import StripeCardPayment from "@/components/StripeCardPayment";

type Lang = "fr" | "en";
type PlanId = "starter" | "standard" | "advanced";
type Jurisdiction = "New Mexico" | "Wyoming";
type PaymentMethod = "credit_card" | "bank_transfer";

type CountryOption = {
  code: string;
  name: string;
  flag: string;
  dial: string;
};

type Plan = {
  id: PlanId;
  name: string;
  prices: Record<Jurisdiction, number>;
  desc: Record<Lang, string>;
  features: Record<Lang, string[]>;
  featured?: boolean;
};

type Service = {
  id: string;
  minPlan: PlanId;
  name: Record<Lang, string>;
  desc: Record<Lang, string>;
};

const planRank: Record<PlanId, number> = {
  starter: 1,
  standard: 2,
  advanced: 3,
};

function countryCodeToFlag(code: string) {
  return code
    .toUpperCase()
    .replace(/./g, (char) => String.fromCodePoint(127397 + char.charCodeAt(0)));
}

const countries: CountryOption[] = countriesRaw
  .filter((country) => country.cca2 !== "EH")
  .map((country) => {
    let dial = "";

    try {
      dial = `+${getCountryCallingCode(country.cca2 as any)}`;
    } catch {
      dial = country.idd?.root || "";
    }

    return {
      code: country.cca2,
      name: country.name.common,
      flag: country.flag || countryCodeToFlag(country.cca2),
      dial,
    };
  })
  .filter((country) => country.dial)
  .sort((a, b) => {
    const priority = ["MA", "FR", "US", "CA", "GB", "ES", "IT", "DE", "AE", "SA"];
    const ai = priority.indexOf(a.code);
    const bi = priority.indexOf(b.code);

    if (ai !== -1 && bi !== -1) return ai - bi;
    if (ai !== -1) return -1;
    if (bi !== -1) return 1;

    return a.name.localeCompare(b.name);
  });

const plans: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    prices: { "New Mexico": 119, Wyoming: 189 },
    desc: {
      fr: "Pour créer votre LLC avec les bases essentielles.",
      en: "An essential setup to launch your LLC.",
    },
    features: {
      fr: [
        "Création de la société LLC",
        "Frais de dépôt de l’État inclus",
        "Agent enregistré inclus la 1re année",
        "Demande EIN incluse",
        "Numéro de téléphone US inclus pendant 3 mois",
        "Suivi administratif de base",
      ],
      en: [
        "LLC formation",
        "State filing fees included",
        "Registered Agent included for the first year",
        "EIN application included",
        "US phone number included for 3 months",
        "Basic administrative follow-up",
      ],
    },
  },
  {
    id: "standard",
    name: "Standard",
    prices: { "New Mexico": 179, Wyoming: 239 },
    desc: {
      fr: "La formule recommandée pour préparer vos outils business.",
      en: "Recommended to prepare your business tools.",
    },
    features: {
      fr: [
        "Tout le pack Starter",
        "Préparation Stripe / PayPal / Wise / Mercury",
        "Assistance à la configuration des comptes business",
        "Suivi renforcé du dossier",
        "Support prioritaire standard",
      ],
      en: [
        "Everything in Starter",
        "Stripe / PayPal / Wise / Mercury preparation",
        "Business account setup guidance",
        "Enhanced case follow-up",
        "Standard priority support",
      ],
    },
    featured: true,
  },
  {
    id: "advanced",
    name: "Advanced",
    prices: { "New Mexico": 199, Wyoming: 299 },
    desc: {
      fr: "Un accompagnement premium avec préparation business et présence en ligne.",
      en: "A premium package with business setup and online presence preparation.",
    },
    features: {
      fr: [
        "Tout le pack Standard",
        "Préparation Stripe / PayPal / Wise / Mercury / Payoneer",
        "Préparation site web professionnel",
        "Accompagnement premium",
        "Support prioritaire",
      ],
      en: [
        "Everything in Standard",
        "Stripe / PayPal / Wise / Mercury / Payoneer preparation",
        "Professional website preparation",
        "Premium assistance",
        "Priority support",
      ],
    },
  },
];

const services: Service[] = [
  {
    id: "ein",
    minPlan: "starter",
    name: { fr: "Demande EIN", en: "EIN application" },
    desc: {
      fr: "Incluse selon l’État : 3 à 7 jours ouvrés Wyoming, 10 à 30 jours ouvrés New Mexico.",
      en: "Included depending on the state: 3 to 7 business days for Wyoming, 10 to 30 business days for New Mexico.",
    },
  },
  {
    id: "phone",
    minPlan: "starter",
    name: { fr: "Numéro de téléphone US — 3 mois", en: "US phone number — 3 months" },
    desc: { fr: "Inclus dans toutes les formules.", en: "Included in all packages." },
  },
  {
    id: "stripe",
    minPlan: "standard",
    name: {
      fr: "Préparation Stripe / PayPal / Wise / Mercury",
      en: "Stripe / PayPal / Wise / Mercury preparation",
    },
    desc: {
      fr: "Incluse à partir de la formule Standard.",
      en: "Included from the Standard package.",
    },
  },
  {
    id: "payoneer",
    minPlan: "advanced",
    name: { fr: "Préparation Payoneer", en: "Payoneer preparation" },
    desc: {
      fr: "Incluse dans la formule Advanced.",
      en: "Included in the Advanced package.",
    },
  },
  {
    id: "website",
    minPlan: "advanced",
    name: {
      fr: "Préparation site web professionnel",
      en: "Professional website preparation",
    },
    desc: {
      fr: "Incluse dans la formule Advanced.",
      en: "Included in the Advanced package.",
    },
  },
];

const copy = {
  fr: {
    steps: ["Plan", "État", "Nom LLC", "Activité", "Compte", "Membres", "Adresse", "Services", "Résumé", "Paiement"],
    summary: "Résumé",
    progress: "Progression",
    package: "Pack",
    stateFees: "Frais de dépôt de l’État",
    included: "Inclus",
    services: "Services",
    selected: "sélectionné(s)",
    clientAccount: "Compte client",
    estimatedTotal: "Total estimé",
    finalNote: "Les frais de dépôt de l’État sont inclus. Le montant final peut varier uniquement en cas de services tiers ou d’options supplémentaires.",
    back: "← Retour",
    continue: "Continuer →",
    choosePlan: "Sélectionnez le niveau d’accompagnement adapté à votre projet LLC.",
    chooseState: "Choisissez l’État de création de votre LLC.",
    llcName: "Nom de votre LLC",
    llcNameHelp: "Indiquez le nom souhaité pour votre société.",
    activityTitle: "Activité de l’entreprise",
    activityHelp: "Décrivez l’activité pour préparer un dossier cohérent.",
    sector: "Secteur d’activité",
    model: "Modèle business",
    description: "Description de l’activité",
    descriptionPlaceholder: "Décrivez votre activité, vos clients et votre objectif.",
    accountTitle: "Création du compte client",
    accountHelp: "Ces informations seront utilisées pour créer votre espace client.",
    fullName: "Nom complet",
    phone: "Téléphone / WhatsApp",
    phoneNumber: "Numéro",
    searchCountry: "Rechercher un pays ou indicatif...",
    email: "Email professionnel",
    membersTitle: "Membre principal",
    membersHelp: "Le nom client est automatiquement proposé comme membre et manager.",
    memberName: "Nom du membre",
    memberRole: "Rôle",
    country: "Pays",
    addressTitle: "Adresse",
    addressHelp: "Adresse de résidence ou adresse principale du client.",
    address: "Adresse",
    city: "Ville",
    postalCode: "Code postal",
    serviceTitle: "Services inclus",
    serviceHelp: "Les services visibles dépendent automatiquement du pack sélectionné.",
    paymentTitle: "Paiement sécurisé",
    paymentHelp: "Le nom et l’email sont repris automatiquement depuis le compte client.",
    billingName: "Nom de facturation",
    billingEmail: "Email de facturation",
    paymentMethod: "Méthode de paiement",
    creditCard: "Carte bancaire",
    bankTransfer: "Virement bancaire",
    loadCardPayment: "Charger le paiement par carte",
    bankTitle: "",
    bankText1: "",
    bankText2: "",
    validNumber: "Numéro valide",
    invalidNumber: "Numéro invalide",
    detected: "Détecté",
    popular: "Recommandé",
    requiredEmail: "Email à compléter",
    businessName: "Nom de la société",
    altName: "Nom alternatif",
    designator: "Désignation",
  },
  en: {
    steps: ["Plan", "State", "LLC name", "Business activity", "Account", "Members", "Address", "Services", "Summary", "Payment"],
    summary: "Summary",
    progress: "Progress",
    package: "Package",
    stateFees: "State filing fees",
    included: "Included",
    services: "Services",
    selected: "selected",
    clientAccount: "Client account",
    estimatedTotal: "Estimated total",
    finalNote: "State filing fees are included. The final amount may only vary if third-party services or additional options are required.",
    back: "← Back",
    continue: "Continue →",
    choosePlan: "Select the right level of support for your LLC project.",
    chooseState: "Choose the state where your LLC will be formed.",
    llcName: "Your LLC name",
    llcNameHelp: "Enter the desired name for your company.",
    activityTitle: "Business activity",
    activityHelp: "Describe the business activity to prepare a consistent case.",
    sector: "Business sector",
    model: "Business model",
    description: "Business activity description",
    descriptionPlaceholder: "Describe your activity, clients and business objective.",
    accountTitle: "Client account creation",
    accountHelp: "This information will be used to create your client portal.",
    fullName: "Full name",
    phone: "Phone / WhatsApp",
    phoneNumber: "Number",
    searchCountry: "Search country or calling code...",
    email: "Business email",
    membersTitle: "Primary member",
    membersHelp: "The client name is automatically suggested as member and manager.",
    memberName: "Member name",
    memberRole: "Role",
    country: "Country",
    addressTitle: "Address",
    addressHelp: "Client residence or primary address.",
    address: "Address",
    city: "City",
    postalCode: "Postal code",
    serviceTitle: "Included services",
    serviceHelp: "Visible services automatically depend on the selected package.",
    paymentTitle: "Secure payment",
    paymentHelp: "Billing name and email are automatically suggested from the client account.",
    billingName: "Billing name",
    billingEmail: "Billing email",
    paymentMethod: "Payment method",
    creditCard: "Credit card",
    bankTransfer: "Bank transfer",
    loadCardPayment: "Load card payment",
    bankTitle: "Vemo bank details",
    bankText1: "Bank details will be added here.",
    bankText2: "After the transfer, send your payment proof to Vemo.",
    validNumber: "Valid number",
    invalidNumber: "Invalid number",
    detected: "Detected",
    popular: "Recommended",
    requiredEmail: "Email required",
    businessName: "Company name",
    altName: "Alternative name",
    designator: "Designator",
  },
};

function normalizePhone(value: string) {
  return value.replace(/[^\d+]/g, "");
}

function findCountry(value: string) {
  return countries.find((country) => country.code === value || country.name === value) || countries.find((country) => country.code === "MA") || countries[0];
}

function detectCountryFromPhone(phone: string) {
  const clean = normalizePhone(phone);

  if (!clean.startsWith("+")) return null;

  return countries
    .slice()
    .sort((a, b) => b.dial.length - a.dial.length)
    .find((country) => clean.startsWith(country.dial)) || null;
}

function localNumber(phone: string, country: CountryOption) {
  const clean = normalizePhone(phone);

  if (clean.startsWith(country.dial)) {
    return clean.slice(country.dial.length);
  }

  return clean.replace(/^\+/, "");
}


function getEinDescription(jurisdiction: Jurisdiction, lang: Lang) {
  if (jurisdiction === "Wyoming") {
    return lang === "fr"
      ? "Demande EIN incluse — délai estimé : 3 à 7 jours ouvrés."
      : "EIN application included — estimated timeline: 3 to 7 business days.";
  }

  return lang === "fr"
    ? "Demande EIN incluse — délai estimé : 10 à 30 jours ouvrés."
    : "EIN application included — estimated timeline: 10 to 30 business days.";
}
function money(value: number) {
  return `$${value}`;
}

function cn(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function CountryDropdown({
  label,
  value,
  onChange,
  withDial = false,
  lang,
}: {
  label: string;
  value: string;
  onChange: (countryCode: string) => void;
  withDial?: boolean;
  lang: Lang;
}) {
  const selected = findCountry(value);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = countries.filter((country) => {
    const text = `${country.name} ${country.code} ${country.dial}`.toLowerCase();
    return text.includes(query.toLowerCase());
  });

  return (
    <div className="relative">
      <span className="mb-2 block text-sm font-black text-slate-700">
        {label}
      </span>

      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex w-full items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left text-sm font-black outline-none transition hover:border-[#0e7490]"
      >
        <span className="truncate">
          {selected.flag} {selected.name} {withDial ? selected.dial : ""}
        </span>
        <span className="text-xs text-slate-400">▼</span>
      </button>

      {open && (
        <div className="absolute z-50 mt-2 w-full overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl shadow-slate-300/60">
          <div className="border-b border-slate-100 p-3">
            <input
              autoFocus
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={copy[lang].searchCountry}
              className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold outline-none focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
            />
          </div>

          <div className="max-h-[260px] overflow-y-auto p-2">
            {filtered.map((country) => (
              <button
                key={country.code}
                type="button"
                onClick={() => {
                  onChange(country.code);
                  setOpen(false);
                  setQuery("");
                }}
                className={cn(
                  "flex w-full items-center justify-between gap-3 rounded-xl px-3 py-3 text-left text-sm font-black hover:bg-cyan-50",
                  selected.code === country.code && "bg-cyan-50 text-[#0e7490]"
                )}
              >
                <span className="truncate">
                  {country.flag} {country.name}
                </span>
                {withDial && <span className="text-slate-500">{country.dial}</span>}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function CountryPhoneInput({
  label,
  value,
  country,
  onChange,
  lang,
}: {
  label: string;
  value: string;
  country: string;
  onChange: (phone: string, countryCode: string) => void;
  lang: Lang;
}) {
  const selected = findCountry(country || "MA");
  const numberOnly = localNumber(value, selected);
  const e164 = value || selected.dial;
  const valid = numberOnly.length === 0 ? true : isValidPhoneNumber(e164);

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const filtered = countries.filter((item) => {
    const text = `${item.name} ${item.code} ${item.dial}`.toLowerCase();
    return text.includes(query.toLowerCase());
  });

  function updateCountry(nextCode: string) {
    const nextCountry = findCountry(nextCode);
    const cleanLocal = numberOnly.replace(/^0+/, "");
    onChange(`${nextCountry.dial}${cleanLocal}`, nextCountry.code);
    setOpen(false);
    setQuery("");
  }

  function updateNumber(nextValue: string) {
    let clean = normalizePhone(nextValue);

    if (clean.startsWith("+")) {
      const detected = detectCountryFromPhone(clean);

      if (detected) {
        onChange(clean, detected.code);
        return;
      }

      onChange(clean, selected.code);
      return;
    }

    clean = clean.replace(/^0+/, "");
    onChange(`${selected.dial}${clean}`, selected.code);
  }

  return (
    <div className="md:col-span-2">
      <span className="mb-2 block text-sm font-black text-slate-700">
        {label}
      </span>

      <div className="grid gap-3 md:grid-cols-[210px_1fr]">
        <div className="relative">
          <button
            type="button"
            onClick={() => setOpen((current) => !current)}
            className="flex w-full items-center justify-between gap-2 rounded-2xl border border-slate-200 bg-white px-4 py-4 text-left text-sm font-black outline-none transition hover:border-[#0e7490] focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
          >
            <span className="truncate">
              {selected.flag} {selected.dial}
            </span>
            <span className="text-xs text-slate-400">▼</span>
          </button>

          {open && (
            <div className="absolute z-50 mt-2 w-[340px] overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl shadow-slate-300/60">
              <div className="border-b border-slate-100 p-3">
                <input
                  autoFocus
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder={copy[lang].searchCountry}
                  className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold outline-none focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                />
              </div>

              <div className="max-h-[260px] overflow-y-auto p-2">
                {filtered.map((item) => (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => updateCountry(item.code)}
                    className={cn(
                      "flex w-full items-center justify-between gap-3 rounded-xl px-3 py-3 text-left text-sm font-black hover:bg-cyan-50",
                      selected.code === item.code && "bg-cyan-50 text-[#0e7490]"
                    )}
                  >
                    <span className="truncate">
                      {item.flag} {item.name}
                    </span>
                    <span className="text-slate-500">{item.dial}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <input
          type="tel"
          value={numberOnly}
          onChange={(event) => updateNumber(event.target.value)}
          placeholder="651983600"
          className={cn(
            "w-full rounded-2xl border bg-white px-5 py-4 text-sm font-black outline-none transition focus:ring-4",
            valid
              ? "border-slate-200 focus:border-[#0e7490] focus:ring-cyan-100"
              : "border-red-300 focus:border-red-500 focus:ring-red-100"
          )}
        />
      </div>

      {!valid && (
        <p className="mt-2 text-xs font-black text-red-600">
          {copy[lang].invalidNumber}
        </p>
      )}
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-slate-700">
        {label}
      </span>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
      />
    </label>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-black text-slate-700">
        {label}
      </span>
      <div className="relative">
        <select
          value={value}
          onChange={(event) => onChange(event.target.value)}
          className="w-full appearance-none rounded-2xl border border-slate-200 bg-white px-5 py-4 pr-10 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
        >
          {options.map((option) => (
            <option key={option}>{option}</option>
          ))}
        </select>
        <span className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-xs font-black text-slate-400">
          ▼
        </span>
      </div>
    </label>
  );
}

function SummaryLine({
  label,
  value,
  detail,
}: {
  label: string;
  value: string;
  detail?: string;
}) {
  return (
    <div className="border-b border-slate-100 py-4">
      <div className="flex items-start justify-between gap-5">
        <div>
          <p className="text-lg font-black text-slate-950">{label}</p>
          {detail && (
            <p className="mt-1 text-xs font-black text-slate-400">{detail}</p>
          )}
        </div>
        <p className="text-xl font-black text-slate-950">{value}</p>
      </div>
    </div>
  );
}

function StepTitle({
  label,
  title,
  subtitle,
}: {
  label: string;
  title: string;
  subtitle: string;
}) {
  return (
    <div>
      <p className="text-sm font-black uppercase tracking-[0.22em] text-[#0e7490]">
        {label}
      </p>
      <h1 className="mt-3 text-4xl font-black tracking-[-0.06em] md:text-5xl">
        {title}
      </h1>
      <p className="mt-4 text-sm font-bold leading-7 text-slate-500">
        {subtitle}
      </p>
    </div>
  );
}

export default function LLCStartWizard({ lang }: { lang: Lang }) {
  const t = copy[lang];
  const params = useSearchParams();

  const initialPlan = String(params.get("plan") || "standard").toLowerCase();
  const initialState = String(params.get("state") || "New Mexico").replace(" LLC", "");

  const [step, setStep] = useState(1);


  const [form, setForm] = useState({
    plan: (["starter", "standard", "advanced"].includes(initialPlan) ? initialPlan : "standard") as PlanId,
    jurisdiction: (initialState === "Wyoming" ? "Wyoming" : "New Mexico") as Jurisdiction,
    company: params.get("company") || "",
    alternativeName: "",
    designator: "LLC",
    activity: "",
    model: "B2B",
    description: "",
    fullName: "",
    email: "",
    phone: "",
    phoneCountry: "MA",
    memberName: "",
    memberCountry: "MA",
    memberRole: "Manager",
    address: "",
    city: "",
    postalCode: "",
    addressCountry: "MA",
    billingName: "",
    billingEmail: "",
    paymentMethod: "credit_card" as PaymentMethod,
  });

  const selectedPlan = plans.find((plan) => plan.id === form.plan) || plans[1];
  const availableServices = services.filter((service) => planRank[service.minPlan] <= planRank[form.plan]);
  const selectedServiceNames = availableServices.map((service) => service.name[lang]);
  const total = selectedPlan.prices[form.jurisdiction];
  const progress = Math.round((step / t.steps.length) * 100);

  useEffect(() => {
    if (step >= 6 && form.fullName) {
      setForm((current) => ({
        ...current,
        memberName: current.memberName || current.fullName,
        memberRole: current.memberRole || "Manager",
      }));
    }

    if (step >= 10 && (form.fullName || form.email)) {
      setForm((current) => ({
        ...current,
        billingName: current.billingName || current.fullName,
        billingEmail: current.billingEmail || current.email,
      }));
    }
  }, [step, form.fullName, form.email]);
const canContinue = useMemo(() => {
    if (step === 1) return Boolean(form.plan);
    if (step === 2) return Boolean(form.jurisdiction);
    if (step === 3) return form.company.trim().length >= 2;
    if (step === 4) return form.description.trim().length >= 3;
    if (step === 5) {
      return (
        form.fullName.trim().length >= 2 &&
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email) &&
        isValidPhoneNumber(form.phone || "")
      );
    }
    if (step === 6) return form.memberName.trim().length >= 2;
    if (step === 7) return form.address.trim().length >= 3 && form.city.trim().length >= 2;
    if (step === 8) return true;
    if (step === 9) return true;
    if (step === 10) return form.billingName.trim().length >= 2 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.billingEmail);
    return true;
  }, [step, form]);
  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function next() {
    if (!canContinue) return;
    setStep((current) => Math.min(current + 1, t.steps.length));
  }

  function prev() {
    setStep((current) => Math.max(current - 1, 1));
  }

  return (
    <main className="min-h-screen bg-[#f4f7fa] text-slate-950">
      <SiteHeader lang={lang} />

      <section className="mx-auto max-w-7xl px-6 py-10">
        <div className="mb-10 overflow-x-auto rounded-[2rem] border border-slate-100 bg-white/80 p-4 shadow-xl shadow-slate-200/70">
          <div className="flex min-w-[980px] gap-3">
            {t.steps.map((item, index) => {
              const number = index + 1;
              const active = step === number;
              const done = step > number;

              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => setStep(number)}
                  className={cn(
                    "flex min-h-[100px] flex-1 flex-col justify-between rounded-2xl border px-4 py-4 text-left transition",
                    active ? "border-[#0e7490] bg-cyan-50" : done ? "border-cyan-100 bg-white" : "border-slate-200 bg-white"
                  )}
                >
                  <span className={cn("flex h-9 w-9 items-center justify-center rounded-full text-xs font-black", active ? "bg-[#0e7490] text-white" : done ? "bg-cyan-100 text-[#0e7490]" : "bg-slate-100 text-slate-400")}>
                    {done ? "✓" : String(number).padStart(2, "0")}
                  </span>
                  <span className="text-sm font-black text-slate-900">{item}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid gap-7 lg:grid-cols-[1fr_420px]">
          <section className="rounded-[2rem] border border-slate-100 bg-white p-7 shadow-xl shadow-slate-200/70 md:p-10">
            {step === 1 && (
              <div>
                <StepTitle label="Step 01" title="Plan" subtitle={t.choosePlan} />
                <div className="mt-8 grid gap-5 md:grid-cols-3">
                  {plans.map((plan) => (
                    <button
                      key={plan.id}
                      type="button"
                      onClick={() => update("plan", plan.id)}
                      className={cn("relative rounded-[1.5rem] border p-6 text-left transition", form.plan === plan.id ? "border-[#0e7490] bg-cyan-50" : "border-slate-200 bg-white")}
                    >
                      {plan.featured && (
                        <span className="rounded-full bg-[#0e7490] px-3 py-1 text-xs font-black uppercase tracking-wide text-white">
                          {t.popular}
                        </span>
                      )}
                      <h3 className="mt-4 text-2xl font-black">{plan.name}</h3>
                      <p className="mt-3 text-5xl font-black tracking-[-0.08em]">
                        {money(plan.prices[form.jurisdiction])}
                      </p>
                      <p className="mt-4 text-sm font-bold leading-7 text-slate-500">
                        {plan.desc[lang]}
                      </p>
                      <div className="mt-5 space-y-2">
                        {plan.features[lang].map((feature) => (
                          <p key={feature} className="text-sm font-black leading-6 text-slate-700">
                            ✓ {feature}
                          </p>
                        ))}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <StepTitle label="Step 02" title={t.steps[1]} subtitle={t.chooseState} />
                <div className="mt-8 grid gap-5 md:grid-cols-2">
                  {(["New Mexico", "Wyoming"] as Jurisdiction[]).map((state) => (
                    <button
                      key={state}
                      type="button"
                      onClick={() => update("jurisdiction", state)}
                      className={cn("rounded-[1.5rem] border p-7 text-left transition", form.jurisdiction === state ? "border-[#0e7490] bg-cyan-50" : "border-slate-200 bg-white")}
                    >
                      <h3 className="text-3xl font-black">{state}</h3>
                      <p className="mt-3 text-sm font-black text-slate-500">
                        {t.stateFees} : {t.included}
                      </p>
                      <p className="mt-2 text-sm font-bold text-slate-500">
                        {state === "Wyoming"
                          ? lang === "fr"
                            ? "Agent enregistré : renouvellement 25 $/an."
                            : "Registered Agent renewal: $25/year."
                          : lang === "fr"
                            ? "Agent enregistré : renouvellement 35 $/an."
                            : "Registered Agent renewal: $35/year."}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 3 && (
              <div>
                <StepTitle label="Step 03" title={t.llcName} subtitle={t.llcNameHelp} />
                <div className="mt-8 grid gap-5 md:grid-cols-2">
                  <Field label={t.businessName} value={form.company} onChange={(value) => update("company", value)} placeholder="Example LLC" />
                  <Field label={t.altName} value={form.alternativeName} onChange={(value) => update("alternativeName", value)} placeholder="Optional" />
                  <SelectField label={t.designator} value={form.designator} onChange={(value) => update("designator", value)} options={["LLC", "L.L.C.", "Limited Liability Company"]} />
                </div>
              </div>
            )}

            {step === 4 && (
              <div>
                <StepTitle label="Step 04" title={t.activityTitle} subtitle={t.activityHelp} />
                <div className="mt-8 grid gap-5 md:grid-cols-2">
                  <SelectField label={t.sector} value={form.activity || "Consulting / Services"} onChange={(value) => update("activity", value)} options={["Consulting / Services", "E-commerce", "Digital products", "Marketing", "Software / SaaS", "Trading", "Other"]} />
                  <SelectField label={t.model} value={form.model} onChange={(value) => update("model", value)} options={["B2B", "B2C", "B2B + B2C", "Marketplace", "Holding"]} />
                </div>

                <label className="mt-6 block">
                  <span className="mb-2 block text-sm font-black text-slate-700">
                    {t.description}
                  </span>
                  <textarea
                    value={form.description}
                    onChange={(event) => update("description", event.target.value)}
                    placeholder={t.descriptionPlaceholder}
                    className="min-h-[150px] w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                  />
                </label>
              </div>
            )}

            {step === 5 && (
              <div>
                <StepTitle label="Step 05" title={t.accountTitle} subtitle={t.accountHelp} />
                <div className="mt-8 grid gap-5 md:grid-cols-2">
                  <Field label={t.fullName} value={form.fullName} onChange={(value) => update("fullName", value)} placeholder={lang === "fr" ? "Nom et prénom" : "Full name"} />
                  <CountryPhoneInput
                    label={t.phone}
                    value={form.phone}
                    country={form.phoneCountry}
                    lang={lang}
                    onChange={(phone, country) => setForm((current) => ({ ...current, phone, phoneCountry: country }))}
                  />
                  <Field label={t.email} value={form.email} onChange={(value) => update("email", value)} placeholder="email@business.com" type="email" />
                </div>
              </div>
            )}

            {step === 6 && (
              <div>
                <StepTitle label="Step 06" title={t.membersTitle} subtitle={t.membersHelp} />
                <div className="mt-8 grid gap-5 md:grid-cols-3">
                  <Field label={t.memberName} value={form.memberName || form.fullName} onChange={(value) => update("memberName", value)} placeholder={form.fullName || t.memberName} />
                  <CountryDropdown label={t.country} value={form.memberCountry} onChange={(value) => update("memberCountry", value)} lang={lang} />
                  <SelectField label={t.memberRole} value={form.memberRole} onChange={(value) => update("memberRole", value)} options={["Manager", "Member", "Owner"]} />
                </div>
              </div>
            )}

            {step === 7 && (
              <div>
                <StepTitle label="Step 07" title={t.addressTitle} subtitle={t.addressHelp} />
                <div className="mt-8 grid gap-5 md:grid-cols-2">
                  <Field label={t.address} value={form.address} onChange={(value) => update("address", value)} placeholder={t.address} />
                  <Field label={t.city} value={form.city} onChange={(value) => update("city", value)} placeholder={t.city} />
                  <Field label={t.postalCode} value={form.postalCode} onChange={(value) => update("postalCode", value)} placeholder={t.postalCode} />
                  <CountryDropdown label={t.country} value={form.addressCountry} onChange={(value) => update("addressCountry", value)} lang={lang} />
                </div>
              </div>
            )}

            {step === 8 && (
              <div>
                <StepTitle label="Step 08" title={t.serviceTitle} subtitle={t.serviceHelp} />
                <div className="mt-8 grid gap-5 md:grid-cols-2">
                  {availableServices.map((service) => (
                    <div key={service.id} className="rounded-[1.5rem] border border-[#0e7490] bg-cyan-50 p-6 shadow-lg shadow-slate-200/70">
                      <div className="flex items-start justify-between gap-4">
                        <h3 className="text-xl font-black">{service.name[lang]}</h3>
                        <span className="rounded-full bg-[#0e7490] px-3 py-1 text-xs font-black text-white">
                          {t.included}
                        </span>
                      </div>
                      <p className="mt-4 text-sm font-bold leading-7 text-slate-500">
                        {service.id === "ein" ? getEinDescription(form.jurisdiction, lang) : service.desc[lang]}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {step === 9 && (
              <div>
                <StepTitle label="Step 09" title={t.summary} subtitle={t.finalNote} />
                <div className="mt-8 rounded-[1.5rem] border border-slate-200 bg-slate-50 p-6">
                  <SummaryLine label={t.package} value={money(total)} detail={`${form.jurisdiction} ${selectedPlan.name}`} />
                  <SummaryLine label={t.stateFees} value={t.included} detail={form.jurisdiction} />
                  <SummaryLine label={t.services} value="$0" detail={`${availableServices.length} ${t.selected}`} />
                  <SummaryLine label={t.clientAccount} value={t.included} detail={form.email || t.requiredEmail} />
                </div>
              </div>
            )}

            {step === 10 && (
              <div>
                <StepTitle label="Step 10" title={t.paymentTitle} subtitle={t.paymentHelp} />
                <div className="mt-8 grid gap-5 md:grid-cols-2">
                  <Field label={t.billingName} value={form.billingName || form.fullName} onChange={(value) => update("billingName", value)} placeholder={t.billingName} />
                  <Field label={t.billingEmail} value={form.billingEmail || form.email} onChange={(value) => update("billingEmail", value)} placeholder="billing@domain.com" type="email" />
                  <SelectField
                    label={t.paymentMethod}
                    value={form.paymentMethod === "credit_card" ? t.creditCard : t.bankTransfer}
                    onChange={(value) => update("paymentMethod", value === t.bankTransfer ? "bank_transfer" : "credit_card")}
                    options={[t.creditCard, t.bankTransfer]}
                  />
                </div>

                <div className="mt-8">
                  {form.paymentMethod === "bank_transfer" ? (
                    <div className="rounded-[2rem] border border-cyan-100 bg-cyan-50/70 p-8">
                      <p className="text-sm font-black uppercase tracking-[0.18em] text-[#0e7490]">
                        {t.bankTransfer}
                      </p>
                      <h3 className="mt-3 text-2xl font-black tracking-[-0.04em] text-slate-950">
                        {t.bankTitle}
                      </h3>
                      <div className="mt-5 rounded-2xl border border-cyan-100 bg-white p-5 text-sm font-bold leading-8 text-slate-600">
                        <p>{t.bankText1}</p>
                        <p>{t.bankText2}</p>
                      </div>
                    </div>
                  ) : (
                    <StripeCardPayment key={`${form.billingEmail || form.email}-${form.billingName || form.fullName}-${total}-${form.jurisdiction}-${form.plan}`}
                          amount={total}
                          customerEmail={form.billingEmail || form.email}
                          customerName={form.billingName || form.fullName}
                          companyName={`${form.company || "LLC"} - ${form.jurisdiction}`}
                          planName={`${form.jurisdiction} ${selectedPlan.name}`}
                          state={form.jurisdiction}
                          services={selectedServiceNames}
                          dossier={{
                            ...form,
                            services: selectedServiceNames,
                            amount: total,
                            state: form.jurisdiction,
                            planName: `${form.jurisdiction} ${selectedPlan.name}`,
                          }}
                         lang={lang} />
                  )}
                </div>
              </div>
            )}

            <div className="mt-9 flex justify-between border-t border-slate-100 pt-6">
              <button type="button" onClick={prev} className="rounded-2xl border border-slate-200 bg-white px-6 py-3 text-sm font-black text-slate-950">
                {t.back}
              </button>

              {step < 10 && (
                <button
                  type="button"
                  onClick={next}
                  className={cn("rounded-2xl px-6 py-3 text-sm font-black text-white shadow-lg", canContinue ? "bg-[#0e7490] shadow-cyan-900/20" : "cursor-not-allowed bg-slate-300 shadow-none")}
                >
                  {t.continue}
                </button>
              )}
            </div>
          </section>

          <aside className="h-fit rounded-[2rem] border border-slate-100 bg-white p-7 shadow-xl shadow-slate-200/70">
            <h2 className="text-4xl font-black tracking-[-0.06em]">{t.summary}</h2>
            <p className="mt-3 text-sm font-black uppercase tracking-[0.14em] text-slate-400">
              {form.company || "LLC"}
            </p>

            <div className="mt-6 h-3 rounded-full bg-slate-100">
              <div className="h-3 rounded-full bg-gradient-to-r from-[#0e7490] to-[#0f2a4f]" style={{ width: `${progress}%` }} />
            </div>
            <p className="mt-3 text-xs font-black uppercase tracking-[0.2em] text-[#0e7490]">
              {t.progress} : {progress}%
            </p>

            <div className="mt-7">
              <SummaryLine label={t.package} value={money(total)} detail={`${form.jurisdiction} ${selectedPlan.name}`} />
              <SummaryLine label={t.stateFees} value={t.included} detail={form.jurisdiction} />
              <SummaryLine label={t.services} value="$0" detail={`${availableServices.length} ${t.selected}`} />
              <SummaryLine label={t.clientAccount} value={t.included} detail={form.email || t.requiredEmail} />
            </div>

            <div className="mt-7 rounded-[1.5rem] border border-cyan-200 bg-cyan-50 p-5">
              <div className="flex items-center justify-between gap-4">
                <p className="text-xl font-black">{t.estimatedTotal}</p>
                <p className="text-5xl font-black tracking-[-0.08em] text-[#0e7490]">
                  {money(total)}
                </p>
              </div>
            </div>

            <p className="mt-5 text-sm font-bold leading-7 text-slate-500">
              {t.finalNote}
            </p>
          </aside>
        </div>
      </section>

      <SiteFooter lang={lang} />
    </main>
  );
}