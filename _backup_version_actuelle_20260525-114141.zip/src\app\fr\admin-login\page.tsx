"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const router = useRouter();

  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    async function checkSession() {
      try {
        const response = await fetch("/api/admin/auth/me", {
          cache: "no-store",
        });

        if (response.ok) {
          router.replace("/fr/admin");
          return;
        }
      } finally {
        setChecking(false);
      }
    }

    checkSession();
  }, [router]);

  async function login() {
    try {
      setLoading(true);
      setMessage("");

      const response = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          password,
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.details || result.error || "Connexion refusée.");
      }

      router.replace("/fr/admin");
    } catch (error) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Connexion admin impossible."
      );
    } finally {
      setLoading(false);
    }
  }

  if (checking) {
    return (
      <main className="min-h-screen bg-[#f7f9fb] p-10 text-slate-950">
        Chargement...
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#f7f9fb] text-slate-950">
      <section className="mx-auto flex min-h-screen max-w-md items-center px-6">
        <div className="w-full rounded-[2rem] border border-slate-200 bg-white p-8 shadow-xl shadow-slate-200/70">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#0e7490] text-lg font-black text-white">
              V
            </div>

            <div>
              <p className="text-2xl font-black tracking-[-0.04em]">
                Vemo Admin
              </p>
              <p className="-mt-1 text-xs font-bold text-slate-500">
                Accès sécurisé
              </p>
            </div>
          </div>

          <h1 className="mt-8 text-3xl font-black tracking-[-0.05em]">
            Connexion admin
          </h1>

          <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">
            Entrez le mot de passe admin pour accéder à la gestion clients,
            documents et dossiers.
          </p>

          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                login();
              }
            }}
            placeholder="Mot de passe admin"
            className="mt-6 w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold outline-none focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
          />

          <button
            type="button"
            onClick={login}
            disabled={loading}
            className="mt-4 w-full rounded-xl bg-[#0e7490] px-5 py-3 text-sm font-black text-white disabled:bg-slate-300"
          >
            {loading ? "Connexion..." : "Se connecter"}
          </button>

          {message && (
            <p className="mt-4 rounded-xl bg-red-50 px-4 py-3 text-sm font-bold text-red-700">
              {message}
            </p>
          )}
        </div>
      </section>
    </main>
  );
}

