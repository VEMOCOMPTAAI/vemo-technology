"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { createBrowserSupabaseClient } from "@/lib/supabaseBrowser";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

function ActivateContent() {
  const searchParams = useSearchParams();
  const token = searchParams.get("token");

  const [loading, setLoading] = useState(true);
  const [account, setAccount] = useState<any>(null);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function load() {
      try {
        if (!token) {
          setMessage("Lien d’activation manquant.");
          setStatus("error");
          return;
        }

        const response = await fetch(`/api/client-portal/activate?token=${token}`);
        const result = await response.json();

        if (!response.ok) {
          throw new Error(result.details || result.error || "Compte introuvable.");
        }

        setAccount(result.account);
      } catch (error) {
        setStatus("error");
        setMessage(
          error instanceof Error ? error.message : "Impossible de charger le compte."
        );
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [token]);

  async function activate() {
    try {
      setStatus("sending");
      setMessage("");

      if (!account?.email) {
        throw new Error("Email client introuvable.");
      }

      if (password.length < 8) {
        throw new Error("Le mot de passe doit contenir au moins 8 caractères.");
      }

      if (password !== confirmPassword) {
        throw new Error("Les mots de passe ne correspondent pas.");
      }

      const supabase = createBrowserSupabaseClient();

      const { error } = await supabase.auth.signUp({
        email: account.email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/fr/auth/callback?next=/fr/espace-client`,
          data: {
            company_name: account.company_name,
            client_account_id: account.id,
          },
        },
      });

      if (error) {
        throw error;
      }

      setStatus("sent");
      setMessage(
        "Email de confirmation envoyé. Vérifiez votre boîte mail, puis cliquez sur le lien de confirmation."
      );
    } catch (error) {
      setStatus("error");
      setMessage(
        error instanceof Error ? error.message : "Impossible d’activer le compte."
      );
    }
  }

  if (loading) {
    return (
      <section className="py-16">
        <div className="mx-auto max-w-4xl px-6">
          <div className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-xl shadow-slate-200/70">
            Chargement du compte client...
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16">
      <div className="mx-auto max-w-4xl px-6">
        <div className="rounded-[2rem] border border-slate-200 bg-white p-8 shadow-xl shadow-slate-200/70">
          <p className="text-sm font-black uppercase tracking-[0.18em] text-[#0e7490]">
            Activation compte client
          </p>

          <h1 className="mt-3 text-4xl font-black tracking-[-0.05em] text-slate-950 md:text-5xl">
            Créez votre accès sécurisé.
          </h1>

          <p className="mt-4 text-sm font-semibold leading-7 text-slate-500">
            Après activation, vous recevrez un email de confirmation. Une fois l’email confirmé,
            vous pourrez vous connecter à votre espace client.
          </p>

          {account && (
            <div className="mt-7 rounded-2xl bg-cyan-50 p-5">
              <p className="text-xs font-black uppercase tracking-[0.16em] text-[#0e7490]">
                Compte à activer
              </p>
              <p className="mt-2 text-xl font-black text-slate-950">
                {account.company_name || "Dossier LLC"}
              </p>
              <p className="mt-1 text-sm font-bold text-slate-500">
                {account.email}
              </p>
            </div>
          )}

          <div className="mt-7 grid gap-5">
            <label>
              <span className="mb-2 block text-sm font-black text-slate-700">
                Mot de passe
              </span>
              <input
                type="password"
                className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-sm font-bold outline-none focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="Minimum 8 caractères"
              />
            </label>

            <label>
              <span className="mb-2 block text-sm font-black text-slate-700">
                Confirmer le mot de passe
              </span>
              <input
                type="password"
                className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-sm font-bold outline-none focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                placeholder="Répéter le mot de passe"
              />
            </label>

            <button
              type="button"
              onClick={activate}
              disabled={status === "sending" || status === "sent"}
              className="rounded-2xl bg-[#0e7490] px-6 py-4 text-sm font-black text-white shadow-lg shadow-cyan-900/20 disabled:cursor-not-allowed disabled:bg-slate-300"
            >
              {status === "sending"
                ? "Envoi de l’email..."
                : status === "sent"
                  ? "Email envoyé"
                  : "Créer mon compte et recevoir l’email"}
            </button>
          </div>

          {message && (
            <div
              className={[
                "mt-6 rounded-2xl p-5 text-sm font-bold leading-7",
                status === "error"
                  ? "bg-red-50 text-red-700"
                  : "bg-cyan-50 text-[#0e7490]",
              ].join(" ")}
            >
              {message}
            </div>
          )}

          {status === "sent" && (
            <div className="mt-6 flex gap-3">
              <a
                href="/fr/connexion"
                className="rounded-2xl border border-slate-200 bg-white px-6 py-4 text-sm font-black text-slate-900 hover:bg-slate-50"
              >
                Aller à la connexion
              </a>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export default function ActivateClientAccountPage() {
  return (
    <main className="min-h-screen bg-[#f4f7fa] text-slate-950">
      <SiteHeader lang="fr" active="start" />

      <Suspense fallback={<section className="p-10">Chargement...</section>}>
        <ActivateContent />
      </Suspense>

      <SiteFooter lang="fr" />
    </main>
  );
}

