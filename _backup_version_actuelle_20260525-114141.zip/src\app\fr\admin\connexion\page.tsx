import AdminLoginPage from "@/components/AdminLoginPage";

export default function FrenchAdminLoginPage() {
  return <AdminLoginPage lang="fr" />;
}