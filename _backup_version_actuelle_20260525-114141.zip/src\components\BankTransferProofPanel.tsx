"use client";

import { useMemo, useState } from "react";

type BankTransferProofPanelProps = {
  locale: "fr" | "en";
  email: string;
  billingName?: string;
  amount: number | string;
};

const WHATSAPP_NUMBER = "212708069471";

export default function BankTransferProofPanel({
  locale,
  email,
  billingName = "",
  amount,
}: BankTransferProofPanelProps) {
  const isFr = locale === "fr";

  const [proofFile, setProofFile] = useState<File | null>(null);
  const [paymentReference, setPaymentReference] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const contactEmail =
    process.env.NEXT_PUBLIC_VEMO_CONTACT_EMAIL || "contact@vemo.technology";

  const amountLabel = useMemo(() => {
    const numeric =
      typeof amount === "number"
        ? amount
        : Number(String(amount).replace(/[^0-9.]/g, ""));

    if (Number.isFinite(numeric)) return `$${numeric}`;
    return String(amount || "");
  }, [amount]);

  const whatsappUrl = useMemo(() => {
    const message = isFr
      ? `Bonjour Vemo, je souhaite finaliser mon paiement par virement. Email client : ${email}. Nom : ${billingName}. Montant : ${amountLabel}.`
      : `Hello Vemo, I would like to finalize my bank transfer payment. Client email: ${email}. Name: ${billingName}. Amount: ${amountLabel}.`;

    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
  }, [amountLabel, billingName, email, isFr]);

  const mailToUrl = useMemo(() => {
    const subject = isFr
      ? `Justificatif de paiement - ${email}`
      : `Payment proof - ${email}`;

    const body = isFr
      ? `Bonjour Vemo,%0D%0A%0D%0AJe vous contacte au sujet de mon paiement par virement.%0D%0AEmail client : ${email}%0D%0ANom de facturation : ${billingName}%0D%0AMontant : ${amountLabel}%0D%0A%0D%0ACordialement`
      : `Hello Vemo,%0D%0A%0D%0AI am contacting you regarding my bank transfer payment.%0D%0AClient email: ${email}%0D%0ABilling name: ${billingName}%0D%0AAmount: ${amountLabel}%0D%0A%0D%0ABest regards`;

    return `mailto:${contactEmail}?subject=${encodeURIComponent(subject)}&body=${body}`;
  }, [amountLabel, billingName, contactEmail, email, isFr]);

  async function handleSubmit() {
    try {
      setErrorMessage("");

      if (!email?.trim()) {
        throw new Error(
          isFr ? "Email de facturation introuvable." : "Billing email not found."
        );
      }

      if (!proofFile) {
        throw new Error(
          isFr
            ? "Veuillez ajouter le justificatif de paiement."
            : "Please upload the payment proof."
        );
      }

      setSubmitting(true);

      const formData = new FormData();
      formData.append("file", proofFile);
      formData.append("email", email.trim());
      formData.append("companyName", billingName || "");
      formData.append("packageName", "");
      formData.append("stateName", "");
      formData.append("amount", String(amount));
      formData.append("paymentReference", paymentReference || "bank_transfer");
      formData.append("payment_method", "bank_transfer");
      formData.append("payment_status", "pending_verification");

      const response = await fetch("/api/client-portal/bank-transfer-proof", {
        method: "POST",
        body: formData,
      });

      const result = await response.json().catch(() => ({}));

      if (!response.ok || !result?.ok) {
        throw new Error(
          result?.error ||
            (isFr
              ? "Impossible d’envoyer le justificatif."
              : "Unable to upload the payment proof.")
        );
      }

      const params = new URLSearchParams({
        email: email.trim(),
        payment_method: "virement",
        payment_status: "pending_verification",
        amount: String(amount),
      });

      if (billingName) params.set("company_name", billingName);

      window.location.href = `/${locale}/activation?${params.toString()}`;
    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : isFr
            ? "Une erreur est survenue."
            : "An error occurred."
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="rounded-[2rem] border border-cyan-100 bg-gradient-to-br from-cyan-50 via-white to-slate-50 p-8 shadow-[0_20px_60px_rgba(14,116,144,0.08)]">
      <div className="flex flex-wrap items-start justify-between gap-5">
        <div>
          <p className="text-sm font-black uppercase tracking-[0.22em] text-[#0e7490]">
            {isFr ? "Paiement par virement" : "Bank transfer payment"}
          </p>

          <h3 className="mt-3 text-3xl font-black tracking-[-0.05em] text-slate-950">
            {isFr ? "Envoyez votre justificatif de paiement" : "Upload your payment proof"}
          </h3>

          <p className="mt-3 max-w-2xl text-sm font-semibold leading-7 text-slate-600">
            {isFr
              ? "Contactez-nous si besoin, ajoutez votre justificatif, puis validez pour créer votre compte client. Le paiement sera marqué en attente de vérification."
              : "Contact us if needed, upload your payment proof, then validate to create your client account. The payment will be marked as pending verification."}
          </p>
        </div>

        <div className="rounded-2xl border border-cyan-200 bg-white px-5 py-4 text-right shadow-sm">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
            {isFr ? "Montant" : "Amount"}
          </p>
          <p className="mt-1 text-3xl font-black tracking-[-0.05em] text-[#0e7490]">
            {amountLabel}
          </p>
        </div>
      </div>

      <div className="mt-6 grid gap-5 md:grid-cols-2">
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noreferrer"
          className="group rounded-[1.6rem] border border-emerald-200 bg-white px-6 py-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg"
        >
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.18em] text-emerald-700">
                WhatsApp
              </p>
              <p className="mt-2 text-xl font-black tracking-[-0.03em] text-slate-950">
                {isFr ? "Contacter Vemo" : "Contact Vemo"}
              </p>
            </div>

            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-lg font-black text-emerald-700 transition group-hover:bg-emerald-100">
              →
            </span>
          </div>

          <p className="mt-3 text-sm font-semibold leading-7 text-slate-600">
            {isFr
              ? "Cliquez pour ouvrir WhatsApp avec un message déjà préparé."
              : "Click to open WhatsApp with a pre-filled message."}
          </p>
        </a>

        <a
          href={mailToUrl}
          className="group rounded-[1.6rem] border border-slate-200 bg-white px-6 py-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-lg"
        >
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-500">
                Email
              </p>
              <p className="mt-2 text-xl font-black tracking-[-0.03em] text-slate-950">
                {isFr ? "Envoyer un email" : "Send an email"}
              </p>
            </div>

            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-50 text-lg font-black text-[#0e7490] transition group-hover:bg-cyan-100">
              →
            </span>
          </div>

          <p className="mt-3 break-all text-sm font-semibold leading-7 text-slate-600">
            {contactEmail}
          </p>
        </a>
      </div>

      <div className="mt-6 rounded-[1.6rem] border border-cyan-100 bg-white p-6 shadow-sm">
        <p className="text-sm font-black uppercase tracking-[0.18em] text-[#0e7490]">
          {isFr ? "Justificatif de paiement" : "Payment proof"}
        </p>

        <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">
          {isFr
            ? "Ajoutez le reçu ou la capture du virement bancaire."
            : "Upload the receipt or screenshot of the bank transfer."}
        </p>

        <div className="mt-5 grid gap-5 md:grid-cols-2">
          <label className="block">
            <span className="mb-2 block text-sm font-black text-slate-700">
              {isFr ? "Référence optionnelle" : "Optional reference"}
            </span>
            <input
              value={paymentReference}
              onChange={(event) => setPaymentReference(event.target.value)}
              placeholder={isFr ? "Ex. référence du virement" : "Ex. transfer reference"}
              className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-sm font-bold outline-none focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
            />
          </label>

          <label className="block">
            <span className="mb-2 block text-sm font-black text-slate-700">
              {isFr ? "Uploader le justificatif" : "Upload proof"}
            </span>
            <input
              type="file"
              accept=".pdf,.png,.jpg,.jpeg,.webp"
              onChange={(event) => setProofFile(event.target.files?.[0] || null)}
              className="block w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-sm font-bold text-slate-700 outline-none file:mr-4 file:rounded-xl file:border-0 file:bg-cyan-50 file:px-4 file:py-2 file:font-black file:text-[#0e7490]"
            />
          </label>
        </div>

        {proofFile && (
          <div className="mt-4 rounded-2xl border border-cyan-100 bg-cyan-50 px-4 py-3 text-sm font-bold text-slate-700">
            {isFr ? "Fichier sélectionné :" : "Selected file:"} {proofFile.name}
          </div>
        )}

        {errorMessage && (
          <div className="mt-4 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-4 text-sm font-black text-rose-700">
            {errorMessage}
          </div>
        )}

        <button
          type="button"
          onClick={handleSubmit}
          disabled={submitting}
          className="mt-6 w-full rounded-2xl bg-gradient-to-r from-[#0e7490] to-[#173b6d] px-7 py-4 text-sm font-black text-white shadow-[0_16px_30px_rgba(14,116,144,0.22)] transition hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting
            ? isFr
              ? "Validation en cours..."
              : "Submitting..."
            : isFr
              ? "Valider et créer mon compte"
              : "Validate and create my account"}
        </button>
      </div>
    </div>
  );
}