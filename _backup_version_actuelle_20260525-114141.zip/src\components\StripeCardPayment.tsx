"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import {
  Elements,
  PaymentElement,
  useElements,
  useStripe,
} from "@stripe/react-stripe-js";

const stripePromise = loadStripe(
  process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || ""
);

type StripeCardPaymentProps = {
  amount: number;
  customerEmail?: string;
  customerName?: string;
  companyName?: string;
  planName?: string;
  state?: string;
  services?: string[];
  dossier?: Record<string, unknown>;
  lang?: "fr" | "en";
};

function money(value: number) {
  return `$${Number(value || 0).toFixed(2)}`;
}

function InnerCardForm({
  amount,
  planName,
  lang = "en",
}: {
  amount: number;
  planName?: string;
  lang?: "fr" | "en";
}) {
  const stripe = useStripe();
  const elements = useElements();

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!stripe || !elements) return;

    setLoading(true);
    setMessage("");

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/${lang}/commencer/success`,
      },
    });

    if (error) {
      setMessage(error.message || "Payment failed.");
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="rounded-[2rem] border border-slate-200 bg-white p-5 shadow-inner">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.18em] text-[#0e7490]">
              {lang === "fr" ? "Paiement carte sécurisé" : "Secure card payment"}
            </p>
            <p className="mt-1 text-sm font-bold text-slate-500">
              {planName || "LLC package"} — {money(amount)}
            </p>
          </div>

          <span className="rounded-full bg-cyan-50 px-4 py-2 text-xs font-black text-[#0e7490]">
            Powered by Stripe
          </span>
        </div>

        <PaymentElement />

        {message && (
          <p className="mt-4 rounded-2xl bg-red-50 px-5 py-4 text-sm font-black text-red-700">
            {message}
          </p>
        )}

        <button
          type="submit"
          disabled={!stripe || !elements || loading}
          className="mt-6 w-full rounded-2xl bg-[#0e7490] px-6 py-4 text-sm font-black text-white shadow-lg shadow-cyan-900/20 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading
            ? lang === "fr"
              ? "Traitement..."
              : "Processing..."
            : lang === "fr"
              ? `Payer ${money(amount)}`
              : `Pay ${money(amount)}`}
        </button>
      </div>
    </form>
  );
}

export default function StripeCardPayment({
  amount,
  customerEmail,
  customerName,
  companyName,
  planName,
  state,
  services,
  dossier,
  lang = "en",
}: StripeCardPaymentProps) {
  const [clientSecret, setClientSecret] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const payload = useMemo(
    () => ({
      amount,
      currency: "usd",
      customerEmail: customerEmail || "",
      customerName: customerName || "",
      companyName: companyName || "",
      planName: planName || "",
      state: state || "",
      services: services || [],
      dossier: dossier || {},
    }),
    [
      amount,
      customerEmail,
      customerName,
      companyName,
      planName,
      state,
      JSON.stringify(services || []),
      JSON.stringify(dossier || {}),
    ]
  );

  const payloadKey = useMemo(() => JSON.stringify(payload), [payload]);

  useEffect(() => {
    let cancelled = false;

    async function createPaymentIntent() {
      setClientSecret("");
      setErrorMessage("");

      try {
        const response = await fetch("/api/stripe/create-payment-intent", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: payloadKey,
        });

        const result = await response.json();

        if (!response.ok || !result.clientSecret) {
          throw new Error(result.error || "Card payment unavailable.");
        }

        if (!cancelled) {
          setClientSecret(result.clientSecret);
        }
      } catch (error) {
        if (!cancelled) {
          setErrorMessage(
            error instanceof Error ? error.message : "Card payment unavailable."
          );
        }
      }
    }

    createPaymentIntent();

    return () => {
      cancelled = true;
    };
  }, [payloadKey]);

  if (!process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) {
    return (
      <div className="rounded-[2rem] border border-red-100 bg-red-50 p-6 text-sm font-black text-red-700">
        NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY manquante dans .env.local.
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="rounded-[2rem] border border-red-100 bg-red-50 p-6 text-sm font-black text-red-700">
        {errorMessage}
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="rounded-[2rem] border border-slate-200 bg-white p-6 text-sm font-black text-slate-500">
        {lang === "fr"
          ? "Chargement du paiement carte..."
          : "Loading card payment..."}
      </div>
    );
  }

  return (
    <Elements
      key={clientSecret}
      stripe={stripePromise}
      options={{
        clientSecret,
        appearance: {
          theme: "stripe",
          variables: {
            borderRadius: "16px",
            fontFamily: "Inter, system-ui, sans-serif",
          },
        },
      }}
    >
      <InnerCardForm amount={amount} planName={planName} lang={lang} />
    </Elements>
  );
}