import type { Metadata, Viewport } from "next";
import { Analytics } from "@vercel/analytics/next";
import "./globals.css";

const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL || "https://vemo-technology.vercel.app";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Vemo Technology | US LLC Formation for Non-Residents",
    template: "%s | Vemo Technology",
  },
  description:
    "Vemo Technology helps non-resident entrepreneurs set up a US LLC with a bilingual online process, Stripe payment, client tracking and admin dashboard.",
  keywords: [
    "US LLC",
    "LLC for non residents",
    "create US company",
    "New Mexico LLC",
    "Wyoming LLC",
    "EIN for non resident",
    "Vemo Technology",
    "création LLC USA",
    "LLC pour non-résidents",
  ],
  authors: [{ name: "Vemo Technology" }],
  creator: "Vemo Technology",
  publisher: "Vemo Technology",
  alternates: {
    canonical: siteUrl,
    languages: {
      fr: "/fr",
      en: "/en",
    },
  },
  openGraph: {
    type: "website",
    url: siteUrl,
    siteName: "Vemo Technology",
    title: "Vemo Technology | US LLC Formation for Non-Residents",
    description:
      "Set up your US LLC as a non-resident through a premium bilingual online platform.",
    locale: "fr_FR",
    alternateLocale: ["en_US"],
  },
  twitter: {
    card: "summary_large_image",
    title: "Vemo Technology | US LLC Formation for Non-Residents",
    description:
      "Create your US LLC as a non-resident with a clear bilingual online process.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#111a33",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr">
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  );
}


