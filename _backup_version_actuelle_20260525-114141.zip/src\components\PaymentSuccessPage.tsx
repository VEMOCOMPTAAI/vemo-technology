"use client";

import { FormEvent, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@supabase/supabase-js";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

type Lang = "fr" | "en";

const WHATSAPP_NUMBER = "212708069471";
const SUPPORT_EMAIL = "contact@vemotechnology.com";

const copy = {
  fr: {
    cardEyebrow: "Paiement confirmé",
    bankEyebrow: "Paiement par virement",
    cardTitle: "Votre paiement a bien été reçu.",
    bankTitle: "Finalisez votre paiement par virement.",
    cardSubtitle:
      "Votre dossier est maintenant enregistré. Créez votre accès sécurisé pour suivre votre dossier.",
    bankSubtitle:
      "Contactez Vemo si besoin, puis envoyez votre justificatif de paiement. Votre dossier passera ensuite en vérification.",
    amountPaid: "Montant",
    status: "Statut",
    succeeded: "Confirmé",
    pending: "En attente de vérification",
    receiptButton: "Télécharger le reçu",
    accountEyebrow: "Compte client",
    accountTitle: "Créez votre accès sécurisé.",
    accountText:
      "Votre email est déjà prérempli. Ajoutez votre mot de passe, confirmez-le, puis validez. Vous recevrez un email de vérification.",
    bankContactTitle: "Besoin d’assistance ?",
    bankContactText:
      "Contactez Vemo via WhatsApp ou email pour confirmer les détails du virement.",
    whatsapp: "Contacter via WhatsApp",
    emailContact: "Contacter par email",
    proofTitle: "Envoyer le justificatif",
    proofText:
      "Ajoutez le reçu ou la capture du virement. Formats acceptés : PDF, JPG, PNG.",
    proofFile: "Justificatif de paiement",
    uploadProof: "Envoyer le justificatif",
    uploadingProof: "Envoi du justificatif...",
    proofSentTitle: "Paiement en attente de vérification.",
    proofSentText:
      "Votre justificatif a bien été reçu. L’équipe Vemo vérifiera votre paiement et mettra à jour votre espace client.",
    email: "Email",
    password: "Mot de passe",
    confirmPassword: "Confirmer le mot de passe",
    passwordPlaceholder: "Créer un mot de passe",
    confirmPlaceholder: "Confirmer votre mot de passe",
    createAccount: "Créer mon compte",
    creating: "Création du compte...",
    alreadyAccount: "Vous avez déjà un compte ?",
    login: "Se connecter",
    verificationSent: "Email de vérification envoyé",
    verificationText:
      "Votre compte a été créé. Vérifiez votre boîte email puis cliquez sur le lien reçu pour activer votre accès client.",
    openLogin: "Accéder à la connexion",
    passwordMismatch: "Les mots de passe ne correspondent pas.",
    weakPassword: "Le mot de passe doit contenir au moins 6 caractères.",
    missingEmail: "Email client introuvable. Contactez Vemo.",
    signupError: "Impossible de créer le compte.",
    proofError: "Impossible d’envoyer le justificatif.",
    receiptDocumentTitle: "Reçu de paiement",
    companyLabel: "Société",
    packageLabel: "Pack",
    stateLabel: "État",
    amountLabel: "Montant",
    paymentRefLabel: "Référence paiement",
    emailLabel: "Email",
  },
  en: {
    cardEyebrow: "Payment confirmed",
    bankEyebrow: "Bank transfer payment",
    cardTitle: "Your payment has been received.",
    bankTitle: "Finalize your bank transfer payment.",
    cardSubtitle:
      "Your case is now registered. Create your secure access to track your case.",
    bankSubtitle:
      "Contact Vemo if needed, then upload your payment proof. Your case will then move to verification.",
    amountPaid: "Amount",
    status: "Status",
    succeeded: "Confirmed",
    pending: "Pending verification",
    receiptButton: "Download receipt",
    accountEyebrow: "Client account",
    accountTitle: "Create your secure access.",
    accountText:
      "Your email is already pre-filled. Add your password, confirm it, then submit. You will receive a verification email.",
    bankContactTitle: "Need assistance?",
    bankContactText:
      "Contact Vemo via WhatsApp or email to confirm the bank transfer details.",
    whatsapp: "Contact via WhatsApp",
    emailContact: "Contact by email",
    proofTitle: "Upload payment proof",
    proofText:
      "Upload the receipt or screenshot of your transfer. Accepted formats: PDF, JPG, PNG.",
    proofFile: "Payment proof",
    uploadProof: "Upload proof",
    uploadingProof: "Uploading proof...",
    proofSentTitle: "Payment pending verification.",
    proofSentText:
      "Your payment proof has been received. Vemo will verify your payment and update your client portal.",
    email: "Email",
    password: "Password",
    confirmPassword: "Confirm password",
    passwordPlaceholder: "Create a password",
    confirmPlaceholder: "Confirm your password",
    createAccount: "Create my account",
    creating: "Creating account...",
    alreadyAccount: "Already have an account?",
    login: "Log in",
    verificationSent: "Verification email sent",
    verificationText:
      "Your account has been created. Check your inbox and click the link to activate your client access.",
    openLogin: "Go to login",
    passwordMismatch: "Passwords do not match.",
    weakPassword: "Password must contain at least 6 characters.",
    missingEmail: "Client email not found. Please contact Vemo.",
    signupError: "Unable to create the account.",
    proofError: "Unable to upload payment proof.",
    receiptDocumentTitle: "Payment receipt",
    companyLabel: "Company",
    packageLabel: "Package",
    stateLabel: "State",
    amountLabel: "Amount",
    paymentRefLabel: "Payment reference",
    emailLabel: "Email",
  },
};

function getSupabaseBrowser() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anon) return null;

  return createClient(url, anon);
}

function clean(value: string | null) {
  return value ? value.trim() : "";
}

function money(value: string) {
  const normalized = value.replace("$", "").trim();

  if (!normalized) return "$119.00";

  const num = Number(normalized);

  if (Number.isNaN(num)) {
    return value.startsWith("$") ? value : `$${value}`;
  }

  return `$${num.toFixed(2)}`;
}

function escapeHtml(input: string) {
  return input
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function isBankMethod(value: string) {
  const v = value.toLowerCase();
  return (
    v.includes("bank") ||
    v.includes("virement") ||
    v.includes("transfer") ||
    v.includes("wire")
  );
}

export default function PaymentSuccessPage({ lang }: { lang: Lang }) {
  const t = copy[lang];
  const params = useSearchParams();

  const supabase = useMemo(() => getSupabaseBrowser(), []);

  const email =
    clean(params.get("email")) ||
    clean(params.get("customer_email")) ||
    clean(params.get("billing_email"));

  const amount =
    clean(params.get("amount")) ||
    clean(params.get("total")) ||
    clean(params.get("paid")) ||
    "119";

  const company =
    clean(params.get("company")) ||
    clean(params.get("company_name")) ||
    clean(params.get("business")) ||
    "";

  const packageName =
    clean(params.get("package")) ||
    clean(params.get("package_name")) ||
    clean(params.get("plan")) ||
    "New Mexico Starter";

  const stateName =
    clean(params.get("state")) ||
    clean(params.get("jurisdiction")) ||
    "New Mexico";

  const paymentIntent =
    clean(params.get("payment_intent")) ||
    clean(params.get("payment_intent_id")) ||
    "";

  const paymentMethod =
    clean(params.get("payment_method")) ||
    clean(params.get("method")) ||
    clean(params.get("mode"));

  const bankTransfer = isBankMethod(paymentMethod);

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [proofFile, setProofFile] = useState<File | null>(null);
  const [uploadingProof, setUploadingProof] = useState(false);
  const [proofUploaded, setProofUploaded] = useState(false);

  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const [proofError, setProofError] = useState("");
  const [created, setCreated] = useState(false);

  const loginHref = useMemo(() => {
    const qs = new URLSearchParams();
    if (email) qs.set("email", email);
    return `/${lang}/connexion${qs.toString() ? `?${qs.toString()}` : ""}`;
  }, [lang, email]);

  const whatsappHref = useMemo(() => {
    const text =
      lang === "fr"
        ? `Bonjour Vemo, je viens de choisir le paiement par virement pour mon dossier LLC. Email: ${email || ""}. Pack: ${packageName}. Montant: ${money(amount)}.`
        : `Hello Vemo, I selected bank transfer payment for my LLC case. Email: ${email || ""}. Package: ${packageName}. Amount: ${money(amount)}.`;

    return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
  }, [lang, email, packageName, amount]);

  const mailHref = useMemo(() => {
    const subject =
      lang === "fr"
        ? "Paiement par virement - dossier LLC"
        : "Bank transfer payment - LLC case";

    const body =
      lang === "fr"
        ? `Bonjour Vemo,%0A%0AJe souhaite confirmer mon paiement par virement.%0AEmail : ${email}%0APack : ${packageName}%0AMontant : ${money(amount)}%0A%0ACordialement.`
        : `Hello Vemo,%0A%0AI would like to confirm my bank transfer payment.%0AEmail: ${email}%0APackage: ${packageName}%0AAmount: ${money(amount)}%0A%0ABest regards.`;

    return `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}&body=${body}`;
  }, [lang, email, packageName, amount]);

  async function uploadProof(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setProofError("");

    if (!email) {
      setProofError(t.missingEmail);
      return;
    }

    if (!proofFile) {
      setProofError(t.proofFile);
      return;
    }

    setUploadingProof(true);

    try {
      const formData = new FormData();

      formData.append("email", email);
      formData.append("companyName", company);
      formData.append("packageName", packageName);
      formData.append("stateName", stateName);
      formData.append("amount", amount);
      formData.append("paymentReference", paymentIntent);
      formData.append("file", proofFile);

      const response = await fetch("/api/client-portal/bank-transfer-proof", {
        method: "POST",
        body: formData,
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || t.proofError);
      }

      setProofUploaded(true);
      setProofFile(null);
    } catch (err) {
      setProofError(err instanceof Error ? err.message : t.proofError);
    } finally {
      setUploadingProof(false);
    }
  }

  async function createAccount(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");

    if (!email) {
      setError(t.missingEmail);
      return;
    }

    if (password.length < 6) {
      setError(t.weakPassword);
      return;
    }

    if (password !== confirmPassword) {
      setError(t.passwordMismatch);
      return;
    }

    if (!supabase) {
      setError("Supabase public variables missing.");
      return;
    }

    setCreating(true);

    try {
      const redirectTo =
        typeof window !== "undefined"
          ? `${window.location.origin}/${lang}/connexion?email=${encodeURIComponent(email)}`
          : undefined;

      const { error: signUpError } = await supabase.auth.signUp({
        email: email.toLowerCase(),
        password,
        options: {
          emailRedirectTo: redirectTo,
          data: {
            source: bankTransfer ? "bank_transfer_pending" : "payment_success",
            company_name: company,
            package_name: packageName,
            state_name: stateName,
            payment_intent: paymentIntent,
            payment_method: bankTransfer ? "bank_transfer" : "card",
          },
        },
      });

      if (signUpError) {
        throw new Error(signUpError.message || t.signupError);
      }

      setCreated(true);
      setPassword("");
      setConfirmPassword("");
    } catch (err) {
      setError(err instanceof Error ? err.message : t.signupError);
    } finally {
      setCreating(false);
    }
  }

  function downloadReceipt() {
    const receiptHtml = `
<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(t.receiptDocumentTitle)}</title>
  <style>
    body {
      margin: 0;
      padding: 40px;
      background: #f4f7fa;
      color: #0b1533;
      font-family: Arial, Helvetica, sans-serif;
    }
    .sheet {
      max-width: 820px;
      margin: 0 auto;
      background: #fff;
      border-radius: 26px;
      padding: 42px;
      border-top: 8px solid #0e7490;
      box-shadow: 0 18px 50px rgba(15,42,79,.12);
    }
    .brand { display: flex; gap: 14px; align-items: center; margin-bottom: 34px; }
    .logo {
      width: 52px;
      height: 52px;
      border-radius: 16px;
      background: linear-gradient(135deg, #0e7490, #0f2a4f);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      font-weight: 900;
    }
    .brand-title { font-size: 28px; font-weight: 900; letter-spacing: -1px; }
    .brand-sub { color: #60718f; font-size: 14px; font-weight: 700; margin-top: 2px; }
    .eyebrow {
      color: #0e7490;
      text-transform: uppercase;
      letter-spacing: .22em;
      font-weight: 900;
      font-size: 12px;
    }
    h1 { margin: 10px 0 10px; font-size: 40px; letter-spacing: -2px; line-height: 1.05; }
    .status {
      display: inline-block;
      margin: 18px 0 28px;
      padding: 11px 16px;
      border-radius: 999px;
      background: ${bankTransfer ? "#fff7ed" : "#e8f8ef"};
      color: ${bankTransfer ? "#c2410c" : "#047857"};
      font-weight: 900;
    }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .item {
      border: 1px solid #e4ebf3;
      background: #fbfdff;
      border-radius: 18px;
      padding: 18px;
    }
    .label {
      color: #6b7893;
      text-transform: uppercase;
      letter-spacing: .12em;
      font-weight: 900;
      font-size: 11px;
      margin-bottom: 8px;
    }
    .value { font-size: 18px; font-weight: 900; word-break: break-word; }
    .footer {
      margin-top: 34px;
      color: #6b7893;
      font-size: 13px;
      font-weight: 700;
      line-height: 1.8;
    }
    @media print {
      body { background: white; padding: 0; }
      .sheet { box-shadow: none; border-radius: 0; max-width: none; }
    }
  </style>
</head>
<body>
  <div class="sheet">
    <div class="brand">
      <div class="logo">V</div>
      <div>
        <div class="brand-title">Vemo Technology</div>
        <div class="brand-sub">US LLC for non-residents</div>
      </div>
    </div>

    <div class="eyebrow">${escapeHtml(t.receiptDocumentTitle)}</div>
    <h1>${escapeHtml(t.receiptDocumentTitle)}</h1>
    <div class="status">${escapeHtml(bankTransfer ? t.pending : t.succeeded)}</div>

    <div class="grid">
      <div class="item"><div class="label">${escapeHtml(t.amountLabel)}</div><div class="value">${escapeHtml(money(amount))}</div></div>
      <div class="item"><div class="label">${escapeHtml(t.emailLabel)}</div><div class="value">${escapeHtml(email || "—")}</div></div>
      <div class="item"><div class="label">${escapeHtml(t.companyLabel)}</div><div class="value">${escapeHtml(company || "—")}</div></div>
      <div class="item"><div class="label">${escapeHtml(t.packageLabel)}</div><div class="value">${escapeHtml(packageName || "—")}</div></div>
      <div class="item"><div class="label">${escapeHtml(t.stateLabel)}</div><div class="value">${escapeHtml(stateName || "—")}</div></div>
      <div class="item"><div class="label">${escapeHtml(t.paymentRefLabel)}</div><div class="value">${escapeHtml(paymentIntent || "—")}</div></div>
    </div>

    <div class="footer">Vemo Technology — Payment confirmation receipt.</div>
  </div>

  <script>window.onload = function() { window.print(); }</script>
</body>
</html>
    `;

    const win = window.open("", "_blank", "width=980,height=900");
    if (!win) return;

    win.document.open();
    win.document.write(receiptHtml);
    win.document.close();
  }

  return (
    <main className="min-h-screen bg-[#f4f7fa] text-slate-950">
      <SiteHeader lang={lang} />

      <section className="mx-auto max-w-6xl px-6 py-14">
        <div className="overflow-hidden rounded-[2rem] border border-slate-100 bg-white shadow-xl shadow-slate-200/70">
          <div className="border-b border-slate-100 p-8 text-center md:p-12">
            <div
              className={
                bankTransfer
                  ? "mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-amber-50 text-3xl font-black text-amber-700"
                  : "mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-emerald-50 text-3xl font-black text-emerald-700"
              }
            >
              {bankTransfer ? "!" : "✓"}
            </div>

            <p className="mt-8 text-sm font-black uppercase tracking-[0.22em] text-[#0e7490]">
              {bankTransfer ? t.bankEyebrow : t.cardEyebrow}
            </p>

            <h1 className="mx-auto mt-4 max-w-4xl text-4xl font-black tracking-[-0.06em] md:text-6xl">
              {bankTransfer ? t.bankTitle : t.cardTitle}
            </h1>

            <p className="mx-auto mt-5 max-w-2xl text-sm font-bold leading-7 text-slate-500">
              {bankTransfer ? t.bankSubtitle : t.cardSubtitle}
            </p>

            <div className="mx-auto mt-8 max-w-xl rounded-[1.5rem] border border-slate-100 bg-slate-50 p-5 text-left">
              <div className="flex items-center justify-between gap-4">
                <span className="text-sm font-black text-slate-500">
                  {t.amountPaid}
                </span>
                <span className="text-sm font-black text-slate-950">
                  {money(amount)}
                </span>
              </div>

              <div className="mt-4 flex items-center justify-between gap-4">
                <span className="text-sm font-black text-slate-500">
                  {t.status}
                </span>
                <span
                  className={
                    bankTransfer
                      ? "rounded-full bg-amber-50 px-3 py-1 text-xs font-black text-amber-700"
                      : "rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700"
                  }
                >
                  {bankTransfer ? t.pending : t.succeeded}
                </span>
              </div>
            </div>

            {!bankTransfer && (
              <button
                type="button"
                onClick={downloadReceipt}
                className="mt-6 rounded-2xl border border-slate-200 bg-white px-6 py-4 text-sm font-black text-slate-950 transition hover:border-[#0e7490] hover:text-[#0e7490]"
              >
                {t.receiptButton}
              </button>
            )}
          </div>

          {bankTransfer && (
            <div className="grid gap-0 border-b border-slate-100 lg:grid-cols-[0.9fr_1.1fr]">
              <div className="bg-gradient-to-br from-cyan-50 via-white to-slate-50 p-8 md:p-10">
                <p className="text-xs font-black uppercase tracking-[0.22em] text-[#0e7490]">
                  {t.bankContactTitle}
                </p>

                <h2 className="mt-4 text-4xl font-black tracking-[-0.06em]">
                  {t.proofTitle}
                </h2>

                <p className="mt-4 text-sm font-bold leading-7 text-slate-500">
                  {t.bankContactText}
                </p>

                <div className="mt-7 grid gap-3 sm:grid-cols-2">
                  <a
                    href={whatsappHref}
                    target="_blank"
                    className="rounded-2xl bg-[#0e7490] px-5 py-4 text-center text-sm font-black text-white shadow-lg shadow-cyan-900/20"
                  >
                    {t.whatsapp}
                  </a>

                  <a
                    href={mailHref}
                    className="rounded-2xl border border-slate-200 bg-white px-5 py-4 text-center text-sm font-black text-slate-950 transition hover:border-[#0e7490] hover:text-[#0e7490]"
                  >
                    {t.emailContact}
                  </a>
                </div>

                {proofUploaded && (
                  <div className="mt-7 rounded-[1.5rem] border border-amber-100 bg-amber-50 p-5">
                    <p className="text-sm font-black text-amber-800">
                      {t.proofSentTitle}
                    </p>
                    <p className="mt-2 text-sm font-bold leading-7 text-amber-900/70">
                      {t.proofSentText}
                    </p>
                  </div>
                )}
              </div>

              <div className="p-8 md:p-10">
                <form onSubmit={uploadProof} className="space-y-5">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.22em] text-[#0e7490]">
                      {t.proofFile}
                    </p>
                    <p className="mt-3 text-sm font-bold leading-7 text-slate-500">
                      {t.proofText}
                    </p>
                  </div>

                  <input
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg,image/png,image/jpeg,application/pdf"
                    onChange={(event) => setProofFile(event.target.files?.[0] || null)}
                    className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                  />

                  {proofError && (
                    <div className="rounded-2xl border border-red-100 bg-red-50 px-5 py-4 text-sm font-black text-red-700">
                      {proofError}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={uploadingProof || !proofFile}
                    className="w-full rounded-2xl bg-[#0e7490] px-6 py-4 text-sm font-black text-white shadow-lg shadow-cyan-900/20 transition hover:bg-[#0b647c] disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {uploadingProof ? t.uploadingProof : t.uploadProof}
                  </button>
                </form>
              </div>
            </div>
          )}

          {(!bankTransfer || proofUploaded) && (
            <div className="grid gap-0 lg:grid-cols-[0.88fr_1.12fr]">
              <div className="bg-gradient-to-br from-cyan-50 via-white to-slate-50 p-8 md:p-10">
                <p className="text-xs font-black uppercase tracking-[0.22em] text-[#0e7490]">
                  {t.accountEyebrow}
                </p>

                <h2 className="mt-4 text-4xl font-black tracking-[-0.06em]">
                  {t.accountTitle}
                </h2>

                <p className="mt-4 text-sm font-bold leading-7 text-slate-500">
                  {t.accountText}
                </p>

                <div className="mt-7 rounded-[1.5rem] border border-cyan-100 bg-white p-5 shadow-lg shadow-cyan-900/5">
                  <div className="flex items-start gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-cyan-50 text-sm font-black text-[#0e7490]">
                      @
                    </div>
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">
                        {t.email}
                      </p>
                      <p className="mt-1 break-all text-sm font-black text-slate-950">
                        {email || "—"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-8 md:p-10">
                {created ? (
                  <div className="rounded-[1.8rem] border border-emerald-100 bg-emerald-50 p-7">
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-2xl font-black text-emerald-700 shadow-sm">
                      ✓
                    </div>

                    <h2 className="mt-5 text-3xl font-black tracking-[-0.05em]">
                      {t.verificationSent}
                    </h2>

                    <p className="mt-3 text-sm font-bold leading-7 text-emerald-900/70">
                      {t.verificationText}
                    </p>

                    <a
                      href={loginHref}
                      className="mt-6 inline-flex rounded-2xl bg-[#0e7490] px-6 py-4 text-sm font-black text-white shadow-lg shadow-cyan-900/20"
                    >
                      {t.openLogin}
                    </a>
                  </div>
                ) : (
                  <form onSubmit={createAccount} className="space-y-5">
                    <label className="block">
                      <span className="mb-2 block text-sm font-black text-slate-700">
                        {t.email}
                      </span>
                      <input
                        type="email"
                        value={email}
                        readOnly
                        className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4 text-sm font-black text-slate-500 outline-none"
                      />
                    </label>

                    <div className="grid gap-5 md:grid-cols-2">
                      <label className="block">
                        <span className="mb-2 block text-sm font-black text-slate-700">
                          {t.password}
                        </span>
                        <input
                          type="password"
                          value={password}
                          onChange={(event) => setPassword(event.target.value)}
                          placeholder={t.passwordPlaceholder}
                          className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                        />
                      </label>

                      <label className="block">
                        <span className="mb-2 block text-sm font-black text-slate-700">
                          {t.confirmPassword}
                        </span>
                        <input
                          type="password"
                          value={confirmPassword}
                          onChange={(event) => setConfirmPassword(event.target.value)}
                          placeholder={t.confirmPlaceholder}
                          className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                        />
                      </label>
                    </div>

                    {error && (
                      <div className="rounded-2xl border border-red-100 bg-red-50 px-5 py-4 text-sm font-black text-red-700">
                        {error}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={creating || !email}
                      className="w-full rounded-2xl bg-[#0e7490] px-6 py-4 text-sm font-black text-white shadow-lg shadow-cyan-900/20 transition hover:bg-[#0b647c] disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {creating ? t.creating : t.createAccount}
                    </button>

                    <div className="border-t border-slate-100 pt-5 text-center">
                      <span className="text-sm font-bold text-slate-500">
                        {t.alreadyAccount}{" "}
                      </span>
                      <a href={loginHref} className="text-sm font-black text-[#0e7490]">
                        {t.login}
                      </a>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>
      </section>

      <SiteFooter lang={lang} />
    </main>
  );
}