"use client";

import { useEffect } from "react";

type PremiumToastProps = {
  open: boolean;
  type?: "success" | "error" | "info";
  title?: string;
  message: string;
  onClose: () => void;
};

export default function PremiumToast({
  open,
  type = "info",
  title,
  message,
  onClose,
}: PremiumToastProps) {
  useEffect(() => {
    if (!open) return;

    const timer = window.setTimeout(() => {
      onClose();
    }, 4200);

    return () => window.clearTimeout(timer);
  }, [open, onClose]);

  if (!open || !message) return null;

  const config =
    type === "success"
      ? {
          icon: "✓",
          eyebrow: "Action réussie",
          title: title || "Opération confirmée",
          iconClass: "bg-emerald-50 text-emerald-700",
          borderClass: "border-emerald-100",
        }
      : type === "error"
        ? {
            icon: "!",
            eyebrow: "Action impossible",
            title: title || "Une erreur est survenue",
            iconClass: "bg-red-50 text-red-600",
            borderClass: "border-red-100",
          }
        : {
            icon: "i",
            eyebrow: "Information",
            title: title || "Notification Vemo",
            iconClass: "bg-cyan-50 text-[#0e7490]",
            borderClass: "border-cyan-100",
          };

  return (
    <div className="fixed right-5 top-24 z-[120] w-[calc(100vw-2.5rem)] max-w-[390px]">
      <section
        className={`overflow-hidden rounded-[1.5rem] border bg-white shadow-2xl shadow-slate-950/15 ${config.borderClass}`}
      >
        <div className="h-1.5 bg-gradient-to-r from-[#0e7490] via-cyan-300 to-[#0f2a4f]" />

        <div className="flex gap-4 p-5">
          <div
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl text-xl font-black ${config.iconClass}`}
          >
            {config.icon}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-black uppercase tracking-[0.22em] text-[#0e7490]">
                  {config.eyebrow}
                </p>

                <h3 className="mt-1 text-lg font-black tracking-[-0.04em] text-slate-950">
                  {config.title}
                </h3>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="rounded-full bg-slate-50 px-3 py-1 text-xs font-black text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
              >
                ×
              </button>
            </div>

            <p className="mt-2 text-sm font-bold leading-6 text-slate-500">
              {message}
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}