"use client";

import { FormEvent, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@supabase/supabase-js";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

type Lang = "fr" | "en";

const copy = {
  fr: {
    eyebrow: "Compte client",
    title: "Créez votre accès sécurisé.",
    text:
      "Créez votre mot de passe. Vous recevrez ensuite un email de confirmation pour activer votre compte et accéder à votre espace client.",
    fullName: "Nom complet",
    email: "Email",
    password: "Mot de passe",
    confirmPassword: "Confirmer le mot de passe",
    create: "Créer mon compte",
    loading: "Création du compte...",
    successTitle: "Email de confirmation envoyé.",
    successText:
      "Vérifiez votre boîte mail et cliquez sur le lien de confirmation pour activer votre compte client.",
    already: "Vous avez déjà un compte ?",
    login: "Se connecter",
    contact: "Contacter Vemo",
    passwordError: "Les mots de passe ne correspondent pas.",
    passwordShort: "Le mot de passe doit contenir au moins 8 caractères.",
    envError:
      "Variables Supabase publiques manquantes : NEXT_PUBLIC_SUPABASE_URL ou NEXT_PUBLIC_SUPABASE_ANON_KEY.",
    genericError: "Impossible de créer le compte pour le moment.",
  },
  en: {
    eyebrow: "Client account",
    title: "Create your secure access.",
    text:
      "Create your password. You will then receive a confirmation email to activate your account and access your client portal.",
    fullName: "Full name",
    email: "Email",
    password: "Password",
    confirmPassword: "Confirm password",
    create: "Create account",
    loading: "Creating account...",
    successTitle: "Confirmation email sent.",
    successText:
      "Check your inbox and click the confirmation link to activate your client account.",
    already: "Already have an account?",
    login: "Log in",
    contact: "Contact Vemo",
    passwordError: "Passwords do not match.",
    passwordShort: "Password must contain at least 8 characters.",
    envError:
      "Missing public Supabase variables: NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY.",
    genericError: "Unable to create the account right now.",
  },
};

export default function ClientActivationPage({ lang }: { lang: Lang }) {
  const t = copy[lang];
  const params = useSearchParams();

  const initialEmail = params.get("email") || "";

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState(initialEmail);
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const supabase = useMemo(() => {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!url || !anon) return null;

    return createClient(url, anon);
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setError("");
    setSuccess(false);

    if (!supabase) {
      setError(t.envError);
      return;
    }

    if (password.length < 8) {
      setError(t.passwordShort);
      return;
    }

    if (password !== confirmPassword) {
      setError(t.passwordError);
      return;
    }

    setLoading(true);

    try {
      const redirectTo =
        typeof window !== "undefined"
          ? `${window.location.origin}/${lang}/connexion`
          : undefined;

      const { error: signUpError } = await supabase.auth.signUp({
        email: email.trim().toLowerCase(),
        password,
        options: {
          emailRedirectTo: redirectTo,
          data: {
            full_name: fullName,
            role: "client",
            source: "vemo_payment_activation",
          },
        },
      });

      if (signUpError) {
        throw signUpError;
      }

      setSuccess(true);
      setPassword("");
      setConfirmPassword("");
    } catch (err) {
      setError(err instanceof Error ? err.message : t.genericError);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#f4f7fa] text-slate-950">
      <SiteHeader lang={lang} />

      <section className="mx-auto flex min-h-[620px] max-w-5xl items-center px-6 py-16">
        <div className="w-full rounded-[2rem] border border-slate-100 bg-white p-8 shadow-xl shadow-slate-200/70 md:p-12">
          <div className="mx-auto max-w-2xl">
            <p className="text-sm font-black uppercase tracking-[0.22em] text-[#0e7490]">
              {t.eyebrow}
            </p>

            <h1 className="mt-4 text-4xl font-black tracking-[-0.06em] md:text-5xl">
              {success ? t.successTitle : t.title}
            </h1>

            <p className="mt-5 text-sm font-bold leading-7 text-slate-500">
              {success ? t.successText : t.text}
            </p>

            {!success && (
              <form onSubmit={handleSubmit} className="mt-8 space-y-5">

                <label className="block">
                  <span className="mb-2 block text-sm font-black text-slate-700">
                    {t.email}
                  </span>
                  <input
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    required
                    className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                  />
                </label>

                <div className="grid gap-5 md:grid-cols-2">
                  <label className="block">
                    <span className="mb-2 block text-sm font-black text-slate-700">
                      {t.password}
                    </span>
                    <input
                      type="password"
                      value={password}
                      onChange={(event) => setPassword(event.target.value)}
                      required
                      minLength={8}
                      className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                    />
                  </label>

                  <label className="block">
                    <span className="mb-2 block text-sm font-black text-slate-700">
                      {t.confirmPassword}
                    </span>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(event) => setConfirmPassword(event.target.value)}
                      required
                      minLength={8}
                      className="w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black outline-none transition focus:border-[#0e7490] focus:ring-4 focus:ring-cyan-100"
                    />
                  </label>
                </div>

                {error && (
                  <p className="rounded-2xl bg-red-50 px-5 py-4 text-sm font-black text-red-700">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-2xl bg-[#0e7490] px-6 py-4 text-sm font-black text-white shadow-lg shadow-cyan-900/20 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {loading ? t.loading : t.create}
                </button>
              </form>
            )}

            <div className="mt-8 flex flex-wrap items-center justify-center gap-3 border-t border-slate-100 pt-6">
              <span className="text-sm font-bold text-slate-500">
                {t.already}
              </span>

              <a
                href={`/${lang}/connexion`}
                className="rounded-2xl border border-slate-200 bg-white px-6 py-4 text-sm font-black text-slate-950"
              >
                {t.login}
              </a>

              <a
                href={`/${lang}/contact`}
                className="rounded-2xl border border-slate-200 bg-white px-6 py-4 text-sm font-black text-slate-950"
              >
                {t.contact}
              </a>
            </div>
          </div>
        </div>
      </section>

      <SiteFooter lang={lang} />
    </main>
  );
}