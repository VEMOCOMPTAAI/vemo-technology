"use client";

import PricingPlans from "@/components/PricingPlans";

import { useState } from "react";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";

const services = [
  {
    title: "Création de LLC",
    text: "Un parcours guidé pour lancer votre société américaine avec plus de clarté.",
  },
  {
    title: "EIN application & Tax ID",
    text: "Accompagnement administratif autour de votre demande EIN application.",
  },
  {
    title: "Operating Agreement",
    text: "Document structuré pour organiser les règles internes de votre LLC.",
  },
  {
    title: "Registered Agent",
    text: "Support autour des informations nécessaires à la constitution du dossier.",
  },
  {
    title: "Basic administrative follow-up",
    text: "Une vision claire des étapes, statuts, documents et prochaines actions.",
  },
  {
    title: "Ressources business",
    text: "Des informations utiles pour avancer avec une structure professionnelle.",
  },
];

const stats = [
  { value: "100%", label: "Processus en ligne" },
  { value: "FR / EN", label: "Accompagnement bilingue" },
  { value: "3", label: "Formules disponibles" },
  { value: "Stripe", label: "Paiement sécurisé" },
];

const plans = [
  {
    name: "New Mexico Starter",
    price: "119 $",
    text: "Une solution simple et économique pour créer votre LLC au Nouveau-Mexique.",
    items: [
      "Création de la société New Mexico LLC",
      "Agent enregistré inclus la 1re année",
      "Renouvellement agent enregistré : 35 $/an",
      "Demande EIN incluse — 10 à 30 jours ouvrés",
      "Numéro de téléphone US inclus pendant 3 mois",
    ],
  },
  {
    name: "New Mexico Standard",
    price: "179 $",
    text: "La formule idéale pour lancer votre LLC et préparer vos outils de paiement.",
    highlighted: true,
    items: [
      "Tout le pack Starter",
      "Préparation Stripe / PayPal / Wise / Mercury",
      "Assistance à la configuration des comptes business",
      "Suivi renforcé du dossier",
      "Support prioritaire standard",
    ],
  },
  {
    name: "New Mexico Advanced",
    price: "199 $",
    text: "La formule complète pour créer votre LLC, préparer vos outils business et votre présence en ligne.",
    items: [
      "Tout le pack Standard",
      "Préparation Stripe / PayPal / Wise / Mercury / Payoneer",
      "Préparation site web professionnel",
      "Accompagnement premium",
      "Support prioritaire",
    ],
  },
  {
    name: "Wyoming Starter",
    price: "189 $",
    text: "Pour créer rapidement votre LLC dans le Wyoming avec les bases essentielles.",
    items: [
      "Création de la société Wyoming LLC",
      "Agent enregistré inclus la 1re année",
      "Renouvellement agent enregistré : 25 $/an",
      "Demande EIN incluse — 3 à 7 jours ouvrés",
      "Numéro de téléphone US inclus pendant 3 mois",
    ],
  },
  {
    name: "Wyoming Standard",
    price: "239 $",
    text: "La formule recommandée pour une structure Wyoming prête à l’usage.",
    highlighted: true,
    items: [
      "Tout le pack Starter",
      "Préparation Stripe / PayPal / Wise / Mercury",
      "Assistance à la configuration des comptes business",
      "Suivi renforcé du dossier",
      "Support prioritaire standard",
    ],
  },
  {
    name: "Wyoming Advanced",
    price: "299 $",
    text: "Un accompagnement premium pour une structure Wyoming complète et business-ready.",
    items: [
      "Tout le pack Standard",
      "Préparation Stripe / PayPal / Wise / Mercury / Payoneer",
      "Préparation site web professionnel",
      "Accompagnement premium",
      "Support prioritaire",
    ],
  },
];

const faqs = [
  "Puis-je créer une LLC sans être résident américain ?",
  "Combien de temps faut-il pour démarrer ?",
  "Quels documents sont nécessaires ?",
  "L’EIN application est-il inclus dans l’accompagnement ?",
  "Vemo remplace-t-il un avocat ou CPA ?",
];

function MiniStartForm() {
  const [company, setCompany] = useState("");
  const [state, setState] = useState("");
  const [activity, setActivity] = useState("");

  const href = `/fr/commencer?company=${encodeURIComponent(company)}&state=${encodeURIComponent(
    state
  )}&activity=${encodeURIComponent(activity)}`;

  return (
    <div className="rounded-[2rem] border border-slate-200 bg-[#0f2a4f] p-6 text-white shadow-2xl shadow-slate-300/70">
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-500/20 text-2xl text-cyan-100">
          ▤
        </div>

        <div>
          <h2 className="text-2xl font-black tracking-[-0.04em]">
            Démarrer votre dossier LLC
          </h2>
          <p className="mt-1 text-sm font-semibold text-slate-300">
            Commencez ici, puis continuez dans le formulaire complet.
          </p>
        </div>
      </div>

      <div className="relative my-7">
        <div className="absolute left-8 right-8 top-4 h-px bg-white/15" />

        <div className="relative grid grid-cols-3 gap-3">
          {["Infos", "Dossier", "Paiement"].map((item, index) => (
            <div key={item} className="text-center">
              <div
                className={[
                  "mx-auto flex h-8 w-8 items-center justify-center rounded-full text-xs font-black",
                  index === 0 ? "bg-[#0e7490] text-white" : "bg-white/15 text-slate-300",
                ].join(" ")}
              >
                {index + 1}
              </div>

              <p className="mt-2 text-[11px] font-black text-slate-300">
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid gap-3">
        <input
          className="vemo-input"
          placeholder="Nom de la société"
          value={company}
          onChange={(event) => setCompany(event.target.value)}
        />

        <select
          className="vemo-input"
          value={state}
          onChange={(event) => setState(event.target.value)}
        >
          <option value="">État de formation</option>
          <option value="New Mexico">New Mexico</option>
          <option value="Wyoming">Wyoming</option>
          <option value="Delaware">Delaware</option>
          <option value="Florida">Florida</option>
        </select>

        <select
          className="vemo-input"
          value={activity}
          onChange={(event) => setActivity(event.target.value)}
        >
          <option value="">Objectif business</option>
          <option value="E-commerce">E-commerce</option>
          <option value="Consulting / Services">Consulting / Services</option>
          <option value="SaaS / Digital">SaaS / Digital</option>
          <option value="Trading / International">Trading / International</option>
          <option value="Autre">Autre</option>
        </select>

        <a
          href={href}
          className="mt-2 rounded-xl bg-[#0e7490] px-5 py-4 text-center text-sm font-black text-white shadow-lg shadow-cyan-900/30 transition hover:-translate-y-0.5 hover:bg-cyan-700"
        >
          Continuer le formulaire →
        </a>
      </div>

      <p className="mt-4 text-center text-xs font-semibold text-slate-400">
        Vous serez redirigé vers le formulaire complet pour finaliser le dossier.
      </p>
    </div>
  );
}

export default function FrenchHomePage() {
  return (
    <main className="min-h-screen text-slate-950">
      <SiteHeader lang="fr" active="home" />

      <section className="py-14 md:py-20">
        <div className="vemo-container grid gap-12 lg:grid-cols-[0.95fr_0.9fr] lg:items-center">
          <div>
            <p className="vemo-badge">Plateforme LLC pour non-résidents</p>

            <h1 className="mt-6 max-w-2xl text-5xl font-black leading-[0.99] tracking-[-0.055em] text-[#0f172a] md:text-6xl">
              Créez votre LLC américaine.{" "}
              <span className="bg-gradient-to-r from-[#0e7490] to-[#0f2a4f] bg-clip-text text-transparent">
                Lancez votre activité.
              </span>
            </h1>

            <p className="mt-6 max-w-xl text-base font-semibold leading-8 text-slate-600 md:text-lg">
              Vemo Technology accompagne les entrepreneurs non-résidents dans la
              création de leur LLC, l’organisation des documents, l’EIN application et le
              suivi administratif.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              {["100% en ligne", "Compte client", "Paiement sécurisé"].map((item) => (
                <span
                  key={item}
                  className="rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-black text-slate-600 shadow-sm"
                >
                  ✓ {item}
                </span>
              ))}
            </div>

            <div className="mt-9 flex flex-wrap gap-4">
              <a href="/fr/commencer" className="vemo-btn-primary">
                Commencer mon dossier <span>→</span>
              </a>

              <a href="/fr/tarifs" className="vemo-btn-secondary">
                Voir les formules
              </a>
            </div>
          </div>

          <MiniStartForm />
        </div>
      </section>

      <section className="pb-10">
        <div className="vemo-container">
          <div className="grid rounded-2xl border border-slate-200 bg-white shadow-xl shadow-slate-200/70 md:grid-cols-4">
            {stats.map((stat, index) => (
              <div
                key={stat.label}
                className={[
                  "flex items-center gap-4 px-7 py-5",
                  index !== 0
                    ? "border-t border-slate-200 md:border-l md:border-t-0"
                    : "",
                ].join(" ")}
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-50 text-xl font-black text-[#0e7490]">
                  ✓
                </div>

                <div>
                  <p className="text-2xl font-black text-[#0f172a]">
                    {stat.value}
                  </p>
                  <p className="text-xs font-black uppercase tracking-wide text-slate-500">
                    {stat.label}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-14">
        <div className="vemo-container">
          <div className="mb-7 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.14em] text-[#0e7490]">
                Ce que vous obtenez
              </p>

              <h2 className="mt-3 max-w-xl text-3xl font-black tracking-[-0.045em] text-[#0f172a] md:text-5xl">
                Tout pour lancer votre LLC avec plus de clarté.
              </h2>
            </div>

            <p className="max-w-md text-sm font-semibold leading-7 text-slate-500">
              Une structure simple pour organiser votre dossier, vos documents
              et les étapes administratives.
            </p>
          </div>

          <div className="grid gap-5 md:grid-cols-3">
            {services.map((service) => (
              <div key={service.title} className="vemo-card p-6">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-50 text-lg font-black text-[#0e7490]">
                  ✓
                </div>

                <h3 className="mt-5 font-black text-slate-950">
                  {service.title}
                </h3>

                <p className="mt-2 text-sm font-medium leading-6 text-slate-600">
                  {service.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-14">
        <div className="vemo-container">
          <div className="mb-7 text-center">
            <p className="text-sm font-black uppercase tracking-[0.14em] text-[#0e7490]">
              Formules
            </p>

            <h2 className="mt-3 text-3xl font-black tracking-[-0.045em] text-[#0f172a] md:text-5xl">
              Choisissez l’accompagnement adapté.
            </h2>
          </div>

          <div className="grid gap-5 md:grid-cols-3">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={[
                  "rounded-[1.65rem] border bg-white p-6 shadow-xl shadow-slate-200/60",
                  plan.highlighted
                    ? "border-[#0e7490] ring-1 ring-[#0e7490]/20"
                    : "border-slate-200",
                ].join(" ")}
              >
                {plan.highlighted && (
                  <p className="-mt-9 mb-4 w-fit rounded-full bg-[#0e7490] px-4 py-1 text-xs font-black uppercase text-white">
                    Recommandé
                  </p>
                )}

                <p className="font-black text-[#0e7490]">{plan.name}</p>

                <p className="mt-3 text-4xl font-black tracking-tight text-[#0f172a]">
                  {plan.price}
                </p>

                <p className="mt-3 text-sm font-medium leading-6 text-slate-500">
                  {plan.text}
                </p>

                <div className="mt-5 space-y-3">
                  {plan.items.map((item) => (
                    <p key={item} className="text-sm font-bold text-slate-600">
                      ✓ {item}
                    </p>
                  ))}
                </div>

                <a
                  href={`/fr/commencer?plan=${encodeURIComponent(plan.name)}`}
                  className={[
                    "mt-6 flex justify-center rounded-xl px-4 py-3 text-sm font-black transition",
                    plan.highlighted
                      ? "bg-[#0e7490] text-white hover:bg-[#0f2a4f]"
                      : "border border-slate-200 text-[#0f172a] hover:bg-cyan-50",
                  ].join(" ")}
                >
                  Choisir {plan.name}
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="pb-14">
        <div className="vemo-container">
          <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.14em] text-[#0e7490]">
                Questions fréquentes
              </p>

              <h2 className="mt-3 max-w-md text-3xl font-black tracking-[-0.045em] text-[#0f172a] md:text-5xl">
                Les réponses avant de commencer.
              </h2>

              <p className="mt-4 max-w-md text-sm font-semibold leading-7 text-slate-500">
                Les informations importantes avant de créer votre dossier LLC.
              </p>
            </div>

            <div className="space-y-3">
              {faqs.map((faq) => (
                <div
                  key={faq}
                  className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black text-slate-800 shadow-sm"
                >
                  {faq}
                  <span className="text-[#0e7490]">⌄</span>
                </div>
              ))}

              <a
                href="/fr/faq"
                className="flex justify-center rounded-2xl border border-slate-200 bg-white px-5 py-4 text-sm font-black text-[#0f172a] shadow-sm hover:bg-cyan-50"
              >
                Voir toutes les questions
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="pb-10">
        <div className="vemo-container">
          <div className="rounded-[2rem] bg-[#0f2a4f] p-7 text-white shadow-2xl shadow-slate-300/70 md:flex md:items-center md:justify-between">
            <div>
              <h2 className="text-3xl font-black tracking-[-0.04em]">
                Prêt à lancer votre LLC ?
              </h2>

              <p className="mt-2 text-sm font-semibold text-slate-300">
                Démarrez votre dossier et avancez étape par étape avec Vemo Technology.
              </p>
            </div>

            <div className="mt-6 flex flex-wrap gap-3 md:mt-0">
              <a href="/fr/commencer" className="vemo-btn-primary">
                Commencer maintenant →
              </a>

              <a
                href="/fr/contact"
                className="rounded-xl border border-white/20 px-5 py-3 text-sm font-black text-white hover:bg-white/10"
              >
                Parler à un expert
              </a>
            </div>
          </div>
        </div>
      </section>

      <SiteFooter lang="fr" />
      <PricingPlans lang="fr" />
    </main>
  );
}

